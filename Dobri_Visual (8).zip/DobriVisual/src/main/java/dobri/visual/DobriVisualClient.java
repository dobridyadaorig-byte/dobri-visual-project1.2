package dobri.visual;
import dobri.visual.config.Config;
import dobri.visual.gui.MenuScreen;
import dobri.visual.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
public class DobriVisualClient implements ClientModInitializer {
  private boolean down;
  @Override public void onInitializeClient() {
    Config.load(); ModuleManager.init();
    LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
      if (renderer instanceof PlayerEntityRenderer pr) helper.register(new dobri.visual.cosmetics.CosmeticFeature(pr));
    });
    HudRenderCallback.EVENT.register((ctx, tick) -> ModuleManager.renderHud(ctx));
    ClientTickEvents.END_CLIENT_TICK.register(mc -> {
      boolean now = GLFW.glfwGetKey(mc.getWindow().getHandle(), Config.menuKey) == GLFW.GLFW_PRESS;
      if (now && !down && mc.currentScreen == null) mc.setScreen(new MenuScreen());
      down = now;
      ModuleManager.tick(mc);
    });
  }
}
