package dobri.visual.gui;
import dobri.visual.module.Module;
import dobri.visual.config.Config;
import dobri.visual.module.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import java.util.List;
public class MenuScreen extends Screen {
  private static final int W = 470, H = 270;
  private long opened; private int cat; private Module sel; private Setting drag; private int dragX;
  public MenuScreen() { this(0); }
  public MenuScreen(int cat) { super(Text.literal("Dobri Visual")); this.cat = cat; }
  @Override protected void init() { opened = System.currentTimeMillis(); }
  @Override public boolean shouldPause() { return false; }
  private int px() { return width / 2 - W / 2; } private int py() { return height / 2 - H / 2; }
  private List<Module> list() { return ModuleManager.byCategory(ModuleManager.CATEGORIES[cat]); }
  @Override public void render(DrawContext c, int mx, int my, float d) {
    // Always paint a safe background first: avoids a black/empty screen if a panel fails to render.
    c.fillGradient(0, 0, width, height, 0x7010101B, 0x60050710);
    Theme t = Theme.cur(); float a = Math.min(1f, (System.currentTimeMillis() - opened) / 200f);
    int x = px(), y = py() + (int) ((1 - a) * 12);
    Draw.panel(c, x, y, W, H, 18, Draw.fade(t.bg, a), t.glass);
    Draw.text(c, textRenderer, "Dobri Visual", x + 12, y + 10, Draw.fade(t.accent, a), true);
    Draw.text(c, textRenderer, t.name, x + W - 12 - textRenderer.getWidth(t.name), y + 10, Draw.fade(t.text, a * 0.6f), false);
    for (int i = 0; i < ModuleManager.CATEGORIES.length; i++) {
      int ty = y + 28 + i * 24; boolean s = i == cat;
      Draw.panel(c, x + 8, ty, 98, 20, 10, Draw.fade(s ? (t.accent & 0xFFFFFF) | 0x66000000 : t.card, a), t.glass);
      Draw.text(c, textRenderer, ModuleManager.CATEGORIES[i], x + 14, ty + 6, Draw.fade(t.text, a), false);
    }
    if (cat == ModuleManager.CATEGORIES.length - 1) {
      String[] rows = {"Theme: " + t.name + "  (ЛКМ/ПКМ)", "HUD Editor", "Keybinds", "Reset Config"};
      for (int i = 0; i < rows.length; i++) {
        int ry = y + 28 + i * 26; boolean h = Draw.in(mx, my, x + 112, ry, 350, 22);
        Draw.panel(c, x + 112, ry, 350, 22, 11, Draw.fade(h ? (t.accent & 0xFFFFFF) | 0x44000000 : t.card, a), t.glass);
        Draw.text(c, textRenderer, rows[i], x + 120, ry + 7, Draw.fade(t.text, a), false);
      }
      drawTrollface(c, width - 43, height - 43, a);
      return;
    }
    List<Module> l = list();
    for (int i = 0; i < l.size(); i++) {
      Module m = l.get(i); int ry = y + 28 + i * 22; boolean on = m.isEnabled(), h = Draw.in(mx, my, x + 112, ry, 190, 20);
      Draw.panel(c, x + 112, ry, 190, 20, 10, Draw.fade(m == sel ? (t.accent & 0xFFFFFF) | 0x44000000 : (h ? t.card | 0x22000000 : t.card), a), t.glass);
      Draw.text(c, textRenderer, m.name, x + 120, ry + 6, Draw.fade(t.text, a), false);
      Draw.round(c, x + 272, ry + 5, 24, 10, 5, on ? t.accent : 0xFF444450);
      c.fill(on ? x + 285 : x + 274, ry + 7, on ? x + 294 : x + 283, ry + 13, 0xFFFFFFFF);
    }
    Draw.text(c, textRenderer, "ПКМ по модулю — настройки", x + 112, y + H - 14, Draw.fade(t.text, a * 0.5f), false);
    drawTrollface(c, width - 43, height - 43, a);
    if (sel != null) {
      int sx = x + 310; Draw.panel(c, sx, y + 28, 152, 226, 14, Draw.fade(t.card, a), t.glass);
      Draw.text(c, textRenderer, sel.name, sx + 8, y + 34, Draw.fade(t.accent, a), true);
      Draw.text(c, textRenderer, textRenderer.trimToWidth(sel.description, 140), sx + 8, y + 46, Draw.fade(t.text, a * 0.6f), false);
      for (int i = 0; i < sel.settings.size(); i++) {
        Setting s = sel.settings.get(i); int ry = y + 62 + i * 22;
        if (s.bool) {
          Draw.text(c, textRenderer, s.name, sx + 8, ry + 5, Draw.fade(t.text, a), false);
          Draw.round(c, sx + 118, ry + 3, 24, 10, 5, s.on() ? t.accent : 0xFF444450);
          c.fill(s.on() ? sx + 131 : sx + 120, ry + 5, s.on() ? sx + 140 : sx + 129, ry + 11, 0xFFFFFFFF);
        } else {
          double f = (s.get() - s.min) / (s.max - s.min);
          c.fill(sx + 8, ry + 14, sx + 144, ry + 17, 0xFF444450); c.fill(sx + 8, ry + 14, sx + 8 + (int) (136 * f), ry + 17, t.accent);
          c.fill(sx + 6 + (int) (136 * f), ry + 12, sx + 10 + (int) (136 * f), ry + 19, 0xFFFFFFFF);
          Draw.text(c, textRenderer, s.name, sx + 8, ry + 2, Draw.fade(t.text, a), false);
          String v = s.labels != null ? s.labels[Math.max(0, Math.min(s.labels.length - 1, (int) Math.round(s.get())))] : String.format("%.1f", s.get()); Draw.text(c, textRenderer, v, sx + 144 - textRenderer.getWidth(v), ry + 2, Draw.fade(t.text, a * 0.7f), false);
        }
      }
    }
  }
  private void drawTrollface(DrawContext c, int x, int y, float a) {
    int white = Draw.fade(0xFFF5F5F5, a), black = Draw.fade(0xFF15151A, a);
    Draw.round(c, x - 19, y - 19, 38, 38, 19, Draw.fade(0xAAFFFFFF, a));
    // Tiny cheeky monochrome trollface badge, drawn with rounded strokes.
    c.fill(x - 12, y - 8, x - 3, y - 4, black);
    c.fill(x + 3, y - 8, x + 12, y - 4, black);
    c.fill(x - 13, y - 11, x - 2, y - 9, black);
    c.fill(x + 2, y - 11, x + 13, y - 9, black);
    c.fill(x - 7, y + 1, x + 8, y + 4, black);
    c.fill(x - 10, y + 5, x + 10, y + 8, black);
    c.fill(x - 8, y + 8, x + 8, y + 10, black);
    c.fill(x - 1, y - 2, x + 2, y + 3, black);
  }
  private void dragTo(double mxp) {
    int sx = px() + 310; double f = Math.max(0, Math.min(1, (mxp - (sx + 8)) / 136.0));
    double v = drag.min + f * (drag.max - drag.min); drag.set(drag.labels != null ? Math.round(v) : Math.round(v * 10) / 10.0);
  }
  @Override public boolean mouseClicked(Click click, boolean doubled) {
    double mx = click.x(), my = click.y(); int x = px(), y = py(), b = click.button();
    for (int i = 0; i < ModuleManager.CATEGORIES.length; i++) if (Draw.in(mx, my, x + 8, y + 28 + i * 24, 98, 20)) { cat = i; sel = null; return true; }
    if (cat == ModuleManager.CATEGORIES.length - 1) {
      for (int i = 0; i < 4; i++) if (Draw.in(mx, my, x + 112, y + 28 + i * 26, 350, 22)) {
        switch (i) { case 0 -> Theme.next(b == 1 ? -1 : 1); case 1 -> client.setScreen(new HudEditorScreen());
          case 2 -> client.setScreen(new KeybindsScreen()); default -> { Config.reset(); ModuleManager.resetPositions(); } }
        return true;
      }
      return false;
    }
    List<Module> l = list();
    for (int i = 0; i < l.size(); i++) if (Draw.in(mx, my, x + 112, y + 28 + i * 22, 190, 20)) { if (b == 1) sel = l.get(i); else { l.get(i).toggle(); } return true; }
    if (sel != null) for (int i = 0; i < sel.settings.size(); i++) {
      Setting s = sel.settings.get(i); int ry = y + 62 + i * 22;
      if (Draw.in(mx, my, x + 310, ry, 152, 22)) { if (s.bool) s.flip(); else { drag = s; dragTo(mx); } return true; }
    }
    return super.mouseClicked(click, doubled);
  }
  @Override public boolean mouseDragged(Click click, double ox, double oy) { if (drag != null) { dragTo(click.x()); return true; } return super.mouseDragged(click, ox, oy); }
  @Override public boolean mouseReleased(Click click) { drag = null; return super.mouseReleased(click); }
  @Override public boolean keyPressed(KeyInput input) {
    if (input.key() == Config.menuKey) { close(); return true; }
    return super.keyPressed(input);
  }
}
