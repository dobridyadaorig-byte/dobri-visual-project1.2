package dobri.visual.gui;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.text.Text;

/** Windows-inspired Dobri launcher. Uses a namespaced font instead of replacing Minecraft's default font. */
public class DobriTitleScreen extends Screen {
  private static final String[] LABELS = {"Одиночная игра", "Сетевая игра", "Настройки", "Косметика", "Выход"};
  private static final String[] SUBS = {"Создать мир или продолжить", "Играть с друзьями", "Видео, звук и управление", "Крылья и аксессуары", "Закрыть Minecraft"};
  private static final int PANEL_W = 330, PANEL_H = 238;
  public DobriTitleScreen() { super(Text.literal("Dobri Visual")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  @Override public boolean shouldPause() { return false; }
  private int panelX() { return width / 2 - PANEL_W / 2; }
  private int panelY() { return height / 2 - PANEL_H / 2 + 12; }
  private int rowY(int i) { return panelY() + 64 + i * 31; }

  @Override public void render(DrawContext c, int mx, int my, float delta) {
    long now = System.currentTimeMillis();
    int top = blend(0xFF101827, 0xFF251A3C, (Math.sin(now / 4200.0) + 1.0) / 2.0);
    c.fillGradient(0, 0, width, height, top, 0xFF070A12);
    // Soft ambient blobs and subtle star-like pixels.
    for (int i = 0; i < 18; i++) {
      int px = (int)((i * 131L + now / 55L) % Math.max(1, width));
      int py = (int)((i * 73L + now / 37L) % Math.max(1, height));
      Draw.round(c, px, py, 2, 2, 1, 0x308FC7FF);
    }
    int x = panelX(), y = panelY();
    Draw.panel(c, x, y, PANEL_W, PANEL_H, 18, 0xB91B2232, true);
    // Windows-style title bar
    Draw.round(c, x + 14, y + 13, 15, 15, 4, 0xFF60A5FA);
    c.fill(x + 17, y + 16, x + 21, y + 20, 0xFFFFFFFF);
    c.fill(x + 22, y + 16, x + 26, y + 20, 0xFFFFFFFF);
    c.fill(x + 17, y + 21, x + 21, y + 25, 0xFFFFFFFF);
    c.fill(x + 22, y + 21, x + 26, y + 25, 0xFFFFFFFF);
    Draw.text(c, textRenderer, "Dobri Visual", x + 36, y + 16, 0xFFFFFFFF, true);
    Draw.text(c, textRenderer, "MINECRAFT EDITION", x + 16, y + 39, 0xFF9CAAC1, false);

    String clock = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
    String date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    Draw.text(c, textRenderer, clock, x + 17, y + 51, 0xFFF8FAFC, true, 2.15f);
    Draw.text(c, textRenderer, date, x + 126, y + 60, 0xFFB8C4D8, false);
    c.fill(x + 16, y + 83, x + PANEL_W - 16, y + 84, 0x30FFFFFF);

    for (int i = 0; i < LABELS.length; i++) {
      int ry = rowY(i); boolean hover = Draw.in(mx, my, x + 13, ry, PANEL_W - 26, 27);
      Draw.panel(c, x + 13, ry, PANEL_W - 26, 27, 8, hover ? 0x604D83C6 : 0x282D394A, true);
      int ix = x + 23, iy = ry + 6;
      Draw.round(c, ix, iy, 15, 15, 4, new int[]{0xFF60A5FA,0xFF34D399,0xFFFBBF24,0xFFC084FC,0xFFF87171}[i]);
      String glyph = new String[]{"▶", "◎", "⚙", "✦", "×"}[i];
      Draw.centerText(c, textRenderer, glyph, ix + 7, iy + 3, 0xFF101522, false);
      Draw.text(c, textRenderer, LABELS[i], x + 47, ry + 4, 0xFFF5F7FB, false);
      Draw.text(c, textRenderer, SUBS[i], x + 47, ry + 16, 0xFF9DAAC0, false, 0.82f);
      Draw.text(c, textRenderer, "›", x + PANEL_W - 31, ry + 7, hover ? 0xFFFFFFFF : 0xFF8795AB, false);
    }
    // Windows-like taskbar
    c.fill(0, height - 27, width, height, 0xB9101420);
    c.fill(0, height - 27, width, height - 26, 0x22FFFFFF);
    int taskX = width / 2 - 29;
    Draw.round(c, taskX, height - 21, 16, 16, 4, 0xFF60A5FA);
    c.fill(taskX + 3, height - 18, taskX + 7, height - 14, 0xFFFFFFFF);
    c.fill(taskX + 8, height - 18, taskX + 13, height - 14, 0xFFFFFFFF);
    c.fill(taskX + 3, height - 13, taskX + 7, height - 8, 0xFFFFFFFF);
    c.fill(taskX + 8, height - 13, taskX + 13, height - 8, 0xFFFFFFFF);
    Draw.round(c, taskX + 22, height - 21, 16, 16, 8, 0xFF293447);
    Draw.centerText(c, textRenderer, "⌕", taskX + 30, height - 18, 0xFFE5E7EB, false);
    Draw.text(c, textRenderer, "Dobri Visual  •  Minecraft 1.21.11", 10, height - 17, 0xFF8F9DB2, false, 0.85f);
    String taskClock = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
    int cw = textRenderer.getWidth(taskClock);
    Draw.text(c, textRenderer, taskClock, width - cw - 13, height - 18, 0xFFE6ECF5, false);
  }

  @Override public boolean mouseClicked(Click click, boolean doubled) {
    for (int i = 0; i < LABELS.length; i++) {
      if (Draw.in(click.x(), click.y(), panelX() + 13, rowY(i), PANEL_W - 26, 27)) {
        switch (i) {
          case 0 -> client.setScreen(new SelectWorldScreen(this));
          case 1 -> client.setScreen(new MultiplayerScreen(this));
          case 2 -> client.setScreen(new OptionsScreen(this, client.options));
          case 3 -> client.setScreen(new MenuScreen(5));
          default -> client.scheduleStop();
        }
        return true;
      }
    }
    return super.mouseClicked(click, doubled);
  }

  private static int blend(int a, int b, double f) {
    int r = 0;
    for (int s = 0; s <= 16; s += 8) r |= ((int)(((a >> s) & 255) * (1 - f) + ((b >> s) & 255) * f)) << s;
    return r | 0xFF000000;
  }
}
