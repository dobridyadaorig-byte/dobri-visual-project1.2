package dobri.visual.gui;
import dobri.visual.module.Module;
import dobri.visual.config.Config;
import dobri.visual.module.*;
import java.util.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
public class KeybindsScreen extends Screen {
  private int waiting = -2; private String msg = "";
  private final List<Module> mods = ModuleManager.MODULES;
  public KeybindsScreen() { super(Text.literal("Keybinds")); }
  @Override public boolean shouldPause() { return false; }
  static String keyName(int k) {
    if (k < 0) return "—"; if (k >= 65 && k <= 90) return String.valueOf((char) k); if (k >= 48 && k <= 57) return String.valueOf((char) k);
    if (k >= 290 && k <= 314) return "F" + (k - 289);
    return switch (k) { case 32 -> "Space"; case 340 -> "L Shift"; case 344 -> "R Shift"; case 341 -> "L Ctrl"; case 345 -> "R Ctrl"; case 342 -> "L Alt"; case 346 -> "R Alt"; case 258 -> "Tab"; default -> "Key " + k; };
  }
  private int rowCount() { return mods.size() + 1; }
  private int rx(int i) { return width / 2 - 205 + (i / 11) * 210; } private int ry(int i) { return 40 + (i % 11) * 22; }
  private String nameOf(int i) { return i == 0 ? "Menu Key" : mods.get(i - 1).name; }
  private int keyOf(int i) { return i == 0 ? Config.menuKey : mods.get(i - 1).key(); }
  @Override public void render(DrawContext c, int mx, int my, float d) {
    Theme t = Theme.cur(); c.fill(0, 0, width, height, 0xAA000000);
    Draw.centerText(c, textRenderer, "Keybinds — клик, затем клавиша. Del = снять, Esc = отмена", width / 2, 12, 0xFFFFFFFF, true);
    Draw.centerText(c, textRenderer, msg, width / 2, 24, 0xFFFF7777, true);
    for (int i = 0; i < rowCount(); i++) {
      boolean w = i == waiting; Draw.panel(c, rx(i), ry(i), 200, 20, 5, w ? (t.accent & 0xFFFFFF) | 0x88000000 : 0xCC1C1C22, t.glass);
      Draw.text(c, textRenderer, nameOf(i), rx(i) + 8, ry(i) + 6, 0xFFFFFFFF, false);
      String k = w ? "..." : keyName(keyOf(i)); Draw.text(c, textRenderer, k, rx(i) + 192 - textRenderer.getWidth(k), ry(i) + 6, 0xFFB794F6, false);
    }
    int by = ry(0) + 11 * 22 + 6; Draw.panel(c, width / 2 - 60, by, 120, 20, 5, 0xCC3A1C1C, false);
    Draw.centerText(c, textRenderer, "Reset Keybinds", width / 2, by + 6, 0xFFFFFFFF, true);
  }
  @Override public boolean mouseClicked(Click click, boolean doubled) {
    for (int i = 0; i < rowCount(); i++) if (Draw.in(click.x(), click.y(), rx(i), ry(i), 200, 20)) { waiting = i; msg = ""; return true; }
    int by = ry(0) + 11 * 22 + 6;
    if (Draw.in(click.x(), click.y(), width / 2 - 60, by, 120, 20)) { Config.keys.clear(); Config.menuKey = 344; Config.save(); msg = ""; return true; }
    return false;
  }
  @Override public boolean keyPressed(KeyInput input) {
    int k = input.key();
    if (waiting < 0) return super.keyPressed(input);
    if (k == 256) { waiting = -2; return true; }
    if (k == 261 || k == 259) { if (waiting == 0) { msg = "Menu Key нельзя снять"; } else Config.keys.put(mods.get(waiting - 1).name, -1); Config.save(); waiting = -2; return true; }
    if (k == Config.menuKey && waiting != 0) { msg = "Конфликт: клавиша занята меню"; return true; }
    for (Module m : mods) if (m.key() == k && !(waiting > 0 && mods.get(waiting - 1) == m)) { msg = "Конфликт: уже занято модулем " + m.name; return true; }
    if (waiting == 0) Config.menuKey = k; else Config.keys.put(mods.get(waiting - 1).name, k);
    Config.save(); waiting = -2; msg = ""; return true;
  }
}
