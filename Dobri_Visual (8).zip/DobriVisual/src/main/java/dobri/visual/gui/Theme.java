package dobri.visual.gui;
import dobri.visual.config.Config;
import java.util.List;
public class Theme {
  public final String name; public final int bg, card, accent, text; public final boolean glass;
  Theme(String n, int bg, int card, int accent, int text, boolean glass) { name = n; this.bg = bg; this.card = card; this.accent = accent; this.text = text; this.glass = glass; }
  public static final List<Theme> ALL = List.of(
    new Theme("Obsidian", 0xE0121216, 0xFF1C1C22, 0xFF8B5CF6, 0xFFFFFFFF, false),
    new Theme("Midnight", 0xE00B1020, 0xFF141B33, 0xFF5B8DEF, 0xFFFFFFFF, false),
    new Theme("Arctic", 0xE8E6EEF5, 0xFFC9DAE8, 0xFF2A8FD6, 0xFF10202C, false),
    new Theme("Emerald", 0xE0081410, 0xFF12261D, 0xFF34D399, 0xFFFFFFFF, false),
    new Theme("Crimson", 0xE0160A0C, 0xFF2A1215, 0xFFEF4444, 0xFFFFFFFF, false),
    new Theme("Violet", 0xE0140C20, 0xFF241636, 0xFFA855F7, 0xFFFFFFFF, false),
    new Theme("Rose", 0xE01A0E14, 0xFF2E1822, 0xFFF472B6, 0xFFFFFFFF, false),
    new Theme("Sunset", 0xE01A100C, 0xFF2E1B14, 0xFFFB923C, 0xFFFFFFFF, false),
    new Theme("Pure Black", 0xFF000000, 0xFF111111, 0xFFFFFFFF, 0xFFFFFFFF, false),
    new Theme("Liquid Glass", 0x70202838, 0x42FFFFFF, 0xFF9AE6FF, 0xFFFFFFFF, true));
  public static Theme cur() { return ALL.get(Math.floorMod(Config.theme, ALL.size())); }
  public static void next(int d) { Config.theme = Math.floorMod(Config.theme + d, ALL.size()); Config.save(); }
}
