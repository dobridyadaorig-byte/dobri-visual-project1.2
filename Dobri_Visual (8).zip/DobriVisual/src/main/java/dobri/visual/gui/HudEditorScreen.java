package dobri.visual.gui;
import dobri.visual.module.Module;
import dobri.visual.module.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
public class HudEditorScreen extends Screen {
  private Module drag; private int ox, oy;
  public HudEditorScreen() { super(Text.literal("HUD Editor")); }
  @Override public boolean shouldPause() { return false; }
  @Override public void render(DrawContext c, int mx, int my, float d) {
    c.fill(0, 0, width, height, 0x66000000);
    Draw.centerText(c, textRenderer, "HUD Editor — перетаскивай элементы мышью, Esc — выход", width / 2, 8, 0xFFFFFFFF, true);
    int acc = Theme.cur().accent;
    for (Module m : ModuleManager.hudModules()) {
      if (!m.isEnabled()) continue;
      m.render(c);
      int w = Math.max(m.w(), 20), h = Math.max(m.h(), 12), col = m == drag ? acc : (acc & 0xFFFFFF) | 0x88000000;
      c.fill(m.x - 1, m.y - 1, m.x + w + 1, m.y, col); c.fill(m.x - 1, m.y + h, m.x + w + 1, m.y + h + 1, col);
      c.fill(m.x - 1, m.y, m.x, m.y + h, col); c.fill(m.x + w, m.y, m.x + w + 1, m.y + h, col);
    }
  }
  @Override public boolean mouseClicked(Click click, boolean doubled) {
    var l = ModuleManager.hudModules();
    for (int i = l.size() - 1; i >= 0; i--) { Module m = l.get(i);
      if (m.isEnabled() && Draw.in(click.x(), click.y(), m.x, m.y, Math.max(m.w(), 20), Math.max(m.h(), 12))) { drag = m; ox = (int) click.x() - m.x; oy = (int) click.y() - m.y; return true; } }
    return false;
  }
  @Override public boolean mouseDragged(Click click, double dx, double dy) {
    if (drag == null) return false;
    drag.setPos(Math.max(0, Math.min(width - 10, (int) click.x() - ox)), Math.max(0, Math.min(height - 10, (int) click.y() - oy))); return true;
  }
  @Override public boolean mouseReleased(Click click) { drag = null; return false; }
}
