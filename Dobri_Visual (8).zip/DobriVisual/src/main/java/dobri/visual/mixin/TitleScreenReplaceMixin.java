package dobri.visual.mixin;

import dobri.visual.gui.DobriTitleScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Replaces only the vanilla title screen; other screens keep their normal behavior. */
@Mixin(MinecraftClient.class)
public abstract class TitleScreenReplaceMixin {
  @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
  private Screen dobri$replaceTitleScreen(Screen screen) {
    return screen != null && screen.getClass() == TitleScreen.class ? new DobriTitleScreen() : screen;
  }
}
