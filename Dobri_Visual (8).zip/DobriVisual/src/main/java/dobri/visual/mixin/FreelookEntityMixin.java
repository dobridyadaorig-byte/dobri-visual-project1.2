package dobri.visual.mixin;
import dobri.visual.module.impl.Freelook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Entity.class)
public class FreelookEntityMixin {
  @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
  private void dobri$look(double dx, double dy, CallbackInfo ci) {
    if (Freelook.active && (Object) this == MinecraftClient.getInstance().player) { Freelook.rotate(dx, dy); ci.cancel(); }
  }
}
