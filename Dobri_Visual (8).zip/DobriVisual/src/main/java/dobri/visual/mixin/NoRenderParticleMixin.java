package dobri.visual.mixin;
import dobri.visual.module.impl.NoRender;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ParticleManager.class)
public class NoRenderParticleMixin {
  @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;", at = @At("HEAD"), cancellable = true)
  private void dobri$hide(ParticleEffect e, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
    if (NoRender.hides(e)) cir.setReturnValue(null);
  }
}
