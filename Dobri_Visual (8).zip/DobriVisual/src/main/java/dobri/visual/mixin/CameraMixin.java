package dobri.visual.mixin;
import dobri.visual.module.impl.Freelook;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(Camera.class)
public class CameraMixin {
  @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0)
  private float dobri$yaw(float yaw) { return Freelook.active ? Freelook.yaw : yaw; }
  @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1)
  private float dobri$pitch(float pitch) { return Freelook.active ? Freelook.pitch : pitch; }
}
