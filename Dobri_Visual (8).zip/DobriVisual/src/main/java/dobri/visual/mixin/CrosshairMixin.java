package dobri.visual.mixin;
import dobri.visual.module.ModuleManager;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public class CrosshairMixin {
  @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
  private void dobri$cross(CallbackInfo ci) {
    var m = ModuleManager.get("Custom Crosshair"); if (m != null && m.isEnabled()) ci.cancel();
  }
}
