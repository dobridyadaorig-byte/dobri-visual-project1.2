package dobri.visual.module.impl;
import net.minecraft.particle.*;

/** Polished client-side particle cosmetics: layered aura, motion ribbons and orbiting sparks. */
public class CosmeticFx extends dobri.visual.module.Module {
  public enum Mode { PARTICLES, AURA, TRAIL, ORBITS }
  private final Mode mode; private double ang; private final java.util.Random rnd = new java.util.Random();
  public CosmeticFx(String name, Mode mode, String desc) {
    super(name, "Cosmetics", desc + " (локальный визуальный эффект)", false, 0, 0); this.mode = mode;
    num("Density", 3, 1, 10); num("Radius", 0.9, 0.3, 2.5); num("Speed", 0.22, 0.05, 0.6); num("Hue", 280, 0, 360); bool("Rainbow", false); bool("First Person", true);
    if (mode == Mode.PARTICLES) num("Style", 0, 0, 4);
    if (mode == Mode.AURA) { bool("Halo", true); bool("Vertical Flow", true); }
    if (mode == Mode.TRAIL) { bool("Ribbon", true); num("Width", 0.65, 0.15, 1.5); }
  }
  @Override public void onTick() {
    var p = mc.player; var w = mc.world; if (!isEnabled() || p == null || w == null) return;
    if (!b("First Person") && mc.options.getPerspective().isFirstPerson()) return;
    int d = (int)n("Density"); double r = n("Radius"); ang += n("Speed");
    var dust = new DustParticleEffect(Fx.rgb(this), 0.72f);
    switch (mode) {
      case PARTICLES -> {
        ParticleEffect e = switch ((int)n("Style")) { case 1 -> ParticleTypes.HEART; case 2 -> ParticleTypes.SNOWFLAKE; case 3 -> ParticleTypes.ELECTRIC_SPARK; case 4 -> dust; default -> ParticleTypes.END_ROD; };
        for (int i=0;i<d;i++) { double a=rnd.nextDouble()*Math.PI*2, rr=r*(.45+rnd.nextDouble()*.55), yy=.15+rnd.nextDouble()*1.75;
          w.addParticleClient(e,p.getX()+Math.cos(a)*rr,p.getY()+yy,p.getZ()+Math.sin(a)*rr,Math.cos(a)*.008,.012,Math.sin(a)*.008); }
      }
      case AURA -> {
        // Two intertwined helices create a brighter, fuller aura rather than random isolated dots.
        for (int i=0;i<d*2;i++) { double a=ang+i*Math.PI*2/(d*2), yy=.12+((i/(double)Math.max(1,d*2)+ang*.055)%1.0)*1.72;
          double rr=r*(.62+.22*Math.sin(a*2)); double x=p.getX()+Math.cos(a)*rr, z=p.getZ()+Math.sin(a)*rr;
          w.addParticleClient(i%3==0?ParticleTypes.END_ROD:dust,x,p.getY()+yy,z,-Math.sin(a)*.012,b("Vertical Flow")?.018:0,Math.cos(a)*.012);
        }
        if (b("Halo")) for(int i=0;i<Math.max(12,d*4);i++){double a=i*Math.PI*2/Math.max(12,d*4)+ang*.35;
          w.addParticleClient(dust,p.getX()+Math.cos(a)*r*1.12,p.getY()+1.05+Math.sin(a*2)*.035,p.getZ()+Math.sin(a)*r*1.12,Math.cos(a)*.006,.004,Math.sin(a)*.006);}
      }
      case TRAIL -> {
        var v=p.getVelocity(); double speed=Math.sqrt(v.x*v.x+v.z*v.z);
        if(speed>.025) for(int i=0;i<d*2;i++) { double back=.15+rnd.nextDouble()*.65, side=(rnd.nextDouble()-.5)*n("Width");
          double len=Math.max(.001,speed); double sx=-v.z/len, sz=v.x/len;
          double x=p.getX()-v.x*back+sx*side, z=p.getZ()-v.z*back+sz*side;
          w.addParticleClient(i%4==0?ParticleTypes.ELECTRIC_SPARK:dust,x,p.getY()+.12+rnd.nextDouble()*.8,z,-v.x*.12,.015,-v.z*.12);
          if(b("Ribbon") && i%2==0) w.addParticleClient(ParticleTypes.END_ROD,x,p.getY()+.18,z,-v.x*.08,.008,-v.z*.08);
        }
      }
      case ORBITS -> { for(int k=0;k<3;k++){double a=ang+k*2.094; double y=p.getY()+1.0+.32*Math.sin(ang*1.4+k*2.1);
        w.addParticleClient(k==1?ParticleTypes.END_ROD:dust,p.getX()+Math.cos(a)*r,y,p.getZ()+Math.sin(a)*r,-Math.sin(a)*.01,.006,Math.cos(a)*.01); } }
    }
  }
}
