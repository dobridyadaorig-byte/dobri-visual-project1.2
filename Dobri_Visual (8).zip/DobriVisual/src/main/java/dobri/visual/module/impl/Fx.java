package dobri.visual.module.impl;
import dobri.visual.module.Module;
public class Fx {
  public static int rgb(Module m) {
    float hue = m.b("Rainbow") ? (System.currentTimeMillis() % 6000) / 6000f : (float) (m.n("Hue") / 360.0);
    return java.awt.Color.HSBtoRGB(hue, 0.85f, 1f) & 0xFFFFFF;
  }
}
