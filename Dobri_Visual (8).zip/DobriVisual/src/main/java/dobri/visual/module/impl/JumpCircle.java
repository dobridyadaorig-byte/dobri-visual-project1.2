package dobri.visual.module.impl;
import java.util.*;
import net.minecraft.particle.DustParticleEffect;

/** Expanding ground ring that breaks into outward-drifting sparkles. */
public class JumpCircle extends dobri.visual.module.Module {
  private final List<double[]> rings = new ArrayList<>(); private boolean was = true;
  private final Random random = new Random();
  public JumpCircle() {
    super("Jump Circle", "Cosmetics", "Круг под ногами: расширяется и рассеивается искрами", false, 0, 0);
    num("Size", 2.8, 0.5, 6); num("Life", 24, 8, 60); num("Thickness", 0.65, 0.2, 1.5); num("Hue", 200, 0, 360); bool("Rainbow", false); bool("Double Ring", true); num("Scatter", 0.45, 0.0, 1.5);
  }
  @Override public void onTick() {
    var p = mc.player; var w = mc.world; if (p == null || w == null) return;
    boolean grounded = p.isOnGround();
    if (isEnabled() && was && !grounded && p.getVelocity().y > 0.08 && rings.size() < 5)
      rings.add(new double[]{p.getX(), p.getY() + 0.035, p.getZ(), 0, random.nextDouble() * 6.28});
    was = grounded;
    Iterator<double[]> it = rings.iterator();
    while (it.hasNext()) {
      double[] ring = it.next(); ring[3]++;
      double life = n("Life"), age = ring[3] / life;
      if (ring[3] > life) { it.remove(); continue; }
      double radius = n("Size") * age;
      int points = Math.max(24, (int)(radius * 26));
      var fx = new DustParticleEffect(Fx.rgb(this), (float)Math.max(0.2, n("Thickness") * (1.0 - age * .55)));
      for (int i = 0; i < points; i++) {
        double angle = (Math.PI * 2 * i / points) + ring[4];
        double jitter = n("Scatter") * age * (random.nextDouble() - .5);
        double rr = radius + jitter;
        double px = ring[0] + Math.cos(angle) * rr, pz = ring[2] + Math.sin(angle) * rr;
        double drift = age * n("Scatter") * .055;
        w.addParticleClient(fx, px, ring[1] + age * .08, pz,
          Math.cos(angle) * drift, .008 + age * .025, Math.sin(angle) * drift);
        if (b("Double Ring") && i % 2 == 0 && age < .82) {
          double inner = radius * .72;
          w.addParticleClient(fx, ring[0] + Math.cos(angle) * inner, ring[1] + .015, ring[2] + Math.sin(angle) * inner,
            Math.cos(angle) * drift * .65, .006, Math.sin(angle) * drift * .65);
        }
      }
    }
  }
}
