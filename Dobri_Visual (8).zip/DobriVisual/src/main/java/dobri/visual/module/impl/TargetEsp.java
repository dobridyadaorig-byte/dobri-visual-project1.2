package dobri.visual.module.impl;

import dobri.visual.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.entity.LivingEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Client-side target ESP using the game's outline pass; original glow state is restored on disable. */
public final class TargetEsp extends Module {
  private final Map<UUID, Boolean> changed = new HashMap<>();
  private Identifier worldId;

  public TargetEsp() {
    super("Target ESP", "Combat Visuals", "Контур ближайших живых целей сквозь препятствия (локально)", false, 0, 0);
    num("Range", 32, 4, 64);
    bool("Players Only", false);
    bool("Mobs", true);
  }

  @Override public void onTick() {
    if (mc.world == null || mc.player == null || !isEnabled()) {
      restore();
      worldId = null;
      return;
    }
    Identifier nowWorld = mc.world.getRegistryKey().getValue();
    if (worldId != null && !worldId.equals(nowWorld)) restore();
    worldId = nowWorld;

    Map<UUID, Entity> current = new HashMap<>();
    double maxSq = n("Range") * n("Range");
    for (Entity e : mc.world.getEntities()) {
      if (!(e instanceof LivingEntity living) || e == mc.player || !e.isAlive()) continue;
      if (mc.player.squaredDistanceTo(e) > maxSq) continue;
      boolean player = living instanceof net.minecraft.entity.player.PlayerEntity;
      if (b("Players Only") && !player) continue;
      if (!player && !b("Mobs")) continue;
      UUID id = e.getUuid();
      current.put(id, e);
      changed.putIfAbsent(id, e.isGlowing());
      if (!e.isGlowing()) e.setGlowing(true);
    }

    for (var it = changed.entrySet().iterator(); it.hasNext();) {
      var entry = it.next();
      if (!current.containsKey(entry.getKey())) {
        Entity e = find(entry.getKey());
        if (e != null) e.setGlowing(entry.getValue());
        it.remove();
      }
    }
  }

  private Entity find(UUID id) {
    if (mc.world == null) return null;
    for (Entity e : mc.world.getEntities()) if (e.getUuid().equals(id)) return e;
    return null;
  }

  private void restore() {
    if (mc.world != null) {
      for (var entry : changed.entrySet()) {
        Entity e = find(entry.getKey());
        if (e != null) e.setGlowing(entry.getValue());
      }
    }
    changed.clear();
  }
}
