package dobri.visual.module.impl;
import dobri.visual.module.Module;
import net.minecraft.client.gui.DrawContext;
public class CustomCrosshair extends Module {
  public CustomCrosshair() {
    super("Custom Crosshair", "Combat Visuals", "Свой прицел: размер, зазор, толщина, цвет", false, 0, 0);
    num("Size", 6, 1, 20); num("Gap", 2, 0, 10); num("Thickness", 1, 1, 4); num("Hue", 280, 0, 360); bool("Rainbow", false); bool("Dot", false);
  }
  @Override public void render(DrawContext c) {
    int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2;
    int s = (int) n("Size"), g = (int) n("Gap"), t = (int) n("Thickness"), o = t / 2; int col = 0xFF000000 | Fx.rgb(this);
    c.fill(cx - g - s, cy - o, cx - g, cy - o + t, col); c.fill(cx + g, cy - o, cx + g + s, cy - o + t, col);
    c.fill(cx - o, cy - g - s, cx - o + t, cy - g, col); c.fill(cx - o, cy + g, cx - o + t, cy + g + s, col);
    if (b("Dot")) c.fill(cx - o, cy - o, cx - o + t, cy - o + t, col);
  }
}
