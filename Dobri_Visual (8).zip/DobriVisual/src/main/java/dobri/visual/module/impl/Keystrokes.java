package dobri.visual.module.impl;
import dobri.visual.gui.Theme;
import net.minecraft.client.gui.DrawContext;
public class Keystrokes extends dobri.visual.module.HudModule {
  public Keystrokes() { super("Keystrokes", "HUD", "Показывает нажатые клавиши W A S D и кнопки мыши", false, 6, 210); }
  private void key(DrawContext c, int x, int y, int w, String s, boolean on) {
    c.fill(x, y, x + w, y + 20, on ? (Theme.cur().accent & 0xFFFFFF) | 0xCC000000 : bg());
    c.drawCenteredTextWithShadow(mc.textRenderer, s, x + w / 2, y + 6, 0xFFFFFFFF);
  }
  @Override protected void content(DrawContext c) {
    var o = mc.options;
    key(c, 22, 0, 20, "W", o.forwardKey.isPressed()); key(c, 0, 22, 20, "A", o.leftKey.isPressed());
    key(c, 22, 22, 20, "S", o.backKey.isPressed()); key(c, 44, 22, 20, "D", o.rightKey.isPressed());
    key(c, 0, 44, 31, "LMB", ClickTracker.lp); key(c, 33, 44, 31, "RMB", ClickTracker.rp);
  }
  @Override protected int cw() { return 64; }
  @Override protected int ch() { return 64; }
}
