package dobri.visual.module;
import net.minecraft.client.gui.DrawContext;
public abstract class HudModule extends Module {
  protected HudModule(String name, String cat, String desc, boolean on, int x, int y) {
    super(name, cat, desc, on, x, y); hud = true;
    num("Scale", 1.0, 0.5, 2.0); num("Opacity", 70, 0, 100);
  }
  protected abstract void content(DrawContext c);
  protected abstract int cw();
  protected abstract int ch();
  protected int bg() { return ((int) (n("Opacity") * 2.55) << 24) | 0x101014; }
  @Override public void render(DrawContext c) {
    float s = (float) n("Scale");
    c.getMatrices().pushMatrix(); c.getMatrices().translate((float) x, (float) y); c.getMatrices().scale(s, s);
    content(c); c.getMatrices().popMatrix();
  }
  @Override public int w() { return (int) (cw() * n("Scale")); }
  @Override public int h() { return (int) (ch() * n("Scale")); }
}
