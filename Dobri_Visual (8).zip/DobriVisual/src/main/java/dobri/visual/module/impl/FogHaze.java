package dobri.visual.module.impl;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
/** World-space ambient mist. Particles are spawned in world coordinates, never as a screen overlay. */
public class FogHaze extends dobri.visual.module.Module {
  private int tick;
  private final java.util.Random random = new java.util.Random();
  public FogHaze() {
    super("World Fog", "World", "Объёмная цветная дымка в игровом мире — частицы в пространстве, не экранный слой", false, 0, 0);
    num("Density", 4, 1, 12); num("Radius", 8, 3, 24); num("Height", 5, 2, 12);
    num("Hue", 200, 0, 360); bool("Rainbow", false); bool("Soft Cloud", true);
  }
  @Override public void onTick() {
    if (!isEnabled() || mc.player == null || mc.world == null) return;
    tick++;
    int density = (int)n("Density");
    // Keep the effect lightweight and distributed through the actual world around the player.
    if (tick % 2 != 0) return;
    double radius = n("Radius"), height = n("Height");
    int rgb = Fx.rgb(this);
    DustParticleEffect dust = new DustParticleEffect(rgb, b("Soft Cloud") ? 1.35f : 0.75f);
    for (int i = 0; i < density; i++) {
      double a = random.nextDouble() * Math.PI * 2;
      double r = radius * Math.sqrt(random.nextDouble());
      double x = mc.player.getX() + Math.cos(a) * r;
      double z = mc.player.getZ() + Math.sin(a) * r;
      double y = mc.player.getY() + 0.3 + random.nextDouble() * height;
      mc.world.addParticleClient(b("Soft Cloud") ? ParticleTypes.CLOUD : dust, x, y, z,
        (random.nextDouble() - .5) * .012, .002 + random.nextDouble() * .006, (random.nextDouble() - .5) * .012);
    }
  }
}
