package dobri.visual.module.impl;
import dobri.visual.module.HudModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
public class ArmorHud extends HudModule {
  public ArmorHud() { super("Armor HUD", "HUD", "Надетая броня и прочность", true, 6, 120); }
  @Override protected void content(DrawContext c) {
    if (mc.player == null) return;
    EquipmentSlot[] s = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    int yy = 0;
    for (EquipmentSlot sl : s) {
      ItemStack st = mc.player.getEquippedStack(sl);
      c.fill(0, yy, 52, yy + 18, bg());
      if (!st.isEmpty()) {
        c.drawItem(st, 1, yy + 1);
        if (st.isDamageable()) c.drawText(mc.textRenderer, String.valueOf(st.getMaxDamage() - st.getDamage()), 20, yy + 5, 0xFFFFFFFF, true);
      }
      yy += 19;
    }
  }
  @Override protected int cw() { return 52; }
  @Override protected int ch() { return 76; }
}
