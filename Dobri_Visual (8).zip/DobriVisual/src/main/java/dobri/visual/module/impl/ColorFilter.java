package dobri.visual.module.impl;
import net.minecraft.client.gui.DrawContext;
public class ColorFilter extends dobri.visual.module.Module {
  public ColorFilter() {
    super("Color Filter", "World", "Цветовой фильтр и яркость поверх мира (экранный, локальный)", false, 0, 0);
    num("Red", 120, 0, 255); num("Green", 160, 0, 255); num("Blue", 255, 0, 255); num("Intensity", 15, 0, 60); num("Brightness", 0, -40, 40);
  }
  @Override public void render(DrawContext c) {
    int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
    int a = (int) (n("Intensity") * 2.55);
    if (a > 0) c.fill(0, 0, w, h, (a << 24) | ((int) n("Red") << 16) | ((int) n("Green") << 8) | (int) n("Blue"));
    int br = (int) n("Brightness");
    if (br > 0) c.fill(0, 0, w, h, ((int) (br * 2.0) << 24) | 0xFFFFFF); else if (br < 0) c.fill(0, 0, w, h, ((int) (-br * 3.0) << 24));
  }
}
