package dobri.visual.module.impl;
import net.minecraft.particle.*;
public class NoRender extends dobri.visual.module.Module {
  public static NoRender inst;
  public NoRender() {
    super("NoRender", "Render", "Скрывает выбранные частицы-эффекты (у каждого свой переключатель)", false, 0, 0);
    inst = this; bool("Rain Splash", true); bool("Portal Particles", true); bool("Smoke", false); bool("Flames", false); bool("Explosions", false); bool("Ash/Spores", false);
  }
  public static boolean hides(ParticleEffect e) {
    if (inst == null || !inst.isEnabled()) return false;
    var t = e.getType();
    if (t == ParticleTypes.RAIN || t == ParticleTypes.SPLASH) return inst.b("Rain Splash");
    if (t == ParticleTypes.PORTAL) return inst.b("Portal Particles");
    if (t == ParticleTypes.SMOKE || t == ParticleTypes.LARGE_SMOKE) return inst.b("Smoke");
    if (t == ParticleTypes.FLAME) return inst.b("Flames");
    if (t == ParticleTypes.EXPLOSION || t == ParticleTypes.EXPLOSION_EMITTER) return inst.b("Explosions");
    if (t == ParticleTypes.ASH || t == ParticleTypes.WHITE_ASH || t == ParticleTypes.SPORE_BLOSSOM_AIR) return inst.b("Ash/Spores");
    return false;
  }
}
