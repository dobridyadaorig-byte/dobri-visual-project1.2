package dobri.visual.module.impl;
import dobri.visual.gui.Theme;
import dobri.visual.module.HudModule;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
public class TextHud extends HudModule {
  private final Supplier<String> text; private int lastW = 60;
  public TextHud(String name, String cat, String desc, boolean on, int x, int y, Supplier<String> text) { super(name, cat, desc, on, x, y); this.text = text; }
  @Override protected void content(DrawContext c) {
    String s = text.get(); if (s == null) return;
    lastW = mc.textRenderer.getWidth(s) + 10;
    c.fill(0, 0, lastW, 14, bg()); c.fill(0, 0, 2, 14, Theme.cur().accent);
    c.drawText(mc.textRenderer, s, 6, 3, 0xFFFFFFFF, true);
  }
  @Override protected int cw() { return lastW; }
  @Override protected int ch() { return 14; }
}
