package dobri.visual.module.impl;
import dobri.visual.module.Module;
import net.minecraft.client.option.Perspective;
public class Freelook extends Module {
  public static boolean active; public static float yaw, pitch; public static Freelook inst;
  private Perspective prev;
  public Freelook() {
    super("Freelook", "Movement", "Удерживай клавишу (по умолчанию Left Alt): камера вращается, направление движения не меняется", false, 0, 0);
    hold = true; defKey = 342; inst = this;
    num("Sensitivity", 1.0, 0.2, 3.0); num("Max Range", 180, 30, 180); bool("Third Person", true);
  }
  @Override public void onTick() {
    boolean now = isEnabled() && keyDown && mc.player != null;
    if (now && !active) {
      yaw = mc.player.getYaw(); pitch = mc.player.getPitch(); prev = mc.options.getPerspective();
      if (b("Third Person")) mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
    } else if (!now && active) {
      if (prev != null) mc.options.setPerspective(prev);
    }
    active = now;
  }
  public static void rotate(double dx, double dy) {
    float s = (float) inst.n("Sensitivity"); float range = (float) inst.n("Max Range"); float base = mc_yaw();
    yaw += (float) dx * 0.15f * s; pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f * s));
    float d = yaw - base; if (d > range) yaw = base + range; if (d < -range) yaw = base - range;
  }
  private static float mc_yaw() { return net.minecraft.client.MinecraftClient.getInstance().player.getYaw(); }
}
