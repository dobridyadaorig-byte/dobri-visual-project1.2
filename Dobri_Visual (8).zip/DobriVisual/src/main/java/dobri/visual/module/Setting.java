package dobri.visual.module;
import dobri.visual.config.Config;
public class Setting {
  public final String key, name; public final double min, max, def; public final boolean bool; public String[] labels;
  public Setting labeled(String... l) { labels = l; return this; }
  public Setting(String module, String name, double def, double min, double max, boolean bool) {
    this.key = module + "." + name; this.name = name; this.def = def; this.min = min; this.max = max; this.bool = bool;
  }
  public double get() { return Config.settings.getOrDefault(key, def); }
  public void set(double v) { Config.settings.put(key, Math.max(min, Math.min(max, v))); Config.dirty(); }
  public boolean on() { return get() >= 0.5; }
  public void flip() { set(on() ? 0 : 1); }
}
