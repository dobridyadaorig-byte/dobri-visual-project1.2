package dobri.visual.module.impl;
import dobri.visual.module.Module;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
public class AutoArmor extends Module {
  private int cd;
  public AutoArmor() {
    super("Auto Armor", "Combat Visuals", "Надевает лучшую броню из инвентаря в пустые слоты (обычный shift-клик)", false, 0, 0);
    num("Delay", 10, 2, 40);
  }
  @Override public void onTick() {
    if (!isEnabled() || mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
    if (cd > 0) { cd--; return; }
    var h = mc.player.playerScreenHandler;
    for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
      if (!mc.player.getEquippedStack(slot).isEmpty()) continue;
      int best = -1, bs = 0;
      for (int i = 9; i < 45; i++) {
        ItemStack s = h.getSlot(i).getStack(); if (s.isEmpty() || s.isOf(Items.ELYTRA)) continue;
        EquippableComponent e = s.get(DataComponentTypes.EQUIPPABLE);
        if (e == null || e.slot() != slot || s.getMaxDamage() <= 0) continue;
        if (s.getMaxDamage() > bs) { bs = s.getMaxDamage(); best = i; }
      }
      if (best >= 0) { mc.interactionManager.clickSlot(h.syncId, best, 0, SlotActionType.QUICK_MOVE, mc.player); cd = (int) n("Delay"); return; }
    }
  }
}
