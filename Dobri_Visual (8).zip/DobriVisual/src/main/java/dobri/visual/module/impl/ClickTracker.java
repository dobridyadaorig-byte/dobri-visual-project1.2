package dobri.visual.module.impl;
import java.util.ArrayDeque;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public class ClickTracker {
  static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
  public static boolean lp, rp;
  public static void poll() {
    var mc = MinecraftClient.getInstance(); long w = mc.getWindow().getHandle(); long now = System.currentTimeMillis();
    boolean l = GLFW.glfwGetMouseButton(w, 0) == GLFW.GLFW_PRESS, r = GLFW.glfwGetMouseButton(w, 1) == GLFW.GLFW_PRESS;
    if (mc.currentScreen == null) { if (l && !lp) L.add(now); if (r && !rp) R.add(now); }
    lp = l; rp = r;
    while (!L.isEmpty() && now - L.peekFirst() > 1000) L.pollFirst();
    while (!R.isEmpty() && now - R.peekFirst() > 1000) R.pollFirst();
  }
  public static String text() { return "CPS " + L.size() + " | " + R.size(); }
}
