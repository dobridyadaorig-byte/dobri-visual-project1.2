package dobri.visual.module;
import dobri.visual.config.Config;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public abstract class Module {
  protected static final MinecraftClient mc = MinecraftClient.getInstance();
  public final String name, category, description; public final boolean defaultOn;
  public boolean hud = false, hold = false, keyDown = false; public int defKey = -1;
  public int x, y; public final int dx, dy;
  public final List<Setting> settings = new ArrayList<>();
  protected Module(String name, String category, String description, boolean on, int x, int y) {
    this.name = name; this.category = category; this.description = description; this.defaultOn = on;
    this.x = x; this.y = y; this.dx = x; this.dy = y;
  }
  protected Setting num(String n, double def, double min, double max) { Setting s = new Setting(name, n, def, min, max, false); settings.add(s); return s; }
  protected Setting bool(String n, boolean def) { Setting s = new Setting(name, n, def ? 1 : 0, 0, 1, true); settings.add(s); return s; }
  public double n(String n) { for (Setting s : settings) if (s.name.equals(n)) return s.get(); return 0; }
  public boolean b(String n) { return n(n) >= 0.5; }
  public int key() { return Config.keys.getOrDefault(name, defKey); }
  public boolean isEnabled() { return Config.enabled.getOrDefault(name, defaultOn); }
  public void toggle() { Config.enabled.put(name, !isEnabled()); Config.save(); }
  public void loadPos() { int[] p = Config.pos.get(name); if (p != null && p.length == 2) { x = p[0]; y = p[1]; } else { x = dx; y = dy; } }
  public void setPos(int nx, int ny) { x = nx; y = ny; Config.pos.put(name, new int[]{x, y}); Config.dirty(); }
  public void onTick() {}
  public void render(DrawContext c) {}
  public int w() { return 0; }
  public int h() { return 0; }
}
