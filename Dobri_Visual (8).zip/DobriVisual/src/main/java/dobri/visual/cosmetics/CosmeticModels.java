package dobri.visual.cosmetics;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModelPartNames;
import net.minecraft.client.model.ModelPart;
import net.minecraft.util.Identifier;
/** Процедурные 3D-модели шляп и крыльев (кубоиды + простые текстуры из ресурсов). */
public class CosmeticModels {
  public static final String[] HATS = {"Top Hat", "Crown", "Wizard Hat", "Cat Ears", "Halo"};
  public static final String[] WINGS = {"Angel", "Demon", "Butterfly"};
  // кубоиды: x, y, z, w, h, d (пиксели, система координат модели игрока: голова сверху = y -8)
  private static final float[][][] HAT = {
    {{-6,-9,-6,12,1,12}, {-4,-15,-4,8,6,8}},
    {{-4.5f,-11,-4.5f,9,3,9}, {-4.5f,-14,-4.5f,2,3,2}, {2.5f,-14,-4.5f,2,3,2}, {-4.5f,-14,2.5f,2,3,2}, {2.5f,-14,2.5f,2,3,2}, {-1,-14,-4.5f,2,3,1}},
    {{-7,-9,-7,14,1,14}, {-4,-13,-4,8,4,8}, {-3,-17,-3,6,4,6}, {-2,-21,-2,4,4,4}, {-1,-24,-1,2,3,2}},
    {{-4.5f,-11,-2,3,3,1}, {1.5f,-11,-2,3,3,1}, {-4,-9,-2,2,1,1}, {2,-9,-2,2,1,1}},
    {{-4,-13,-4,8,0.6f,1}, {-4,-13,3,8,0.6f,1}, {-4,-13,-3,1,0.6f,6}, {3,-13,-3,1,0.6f,6}}
  };
  // кубоиды правого крыла: x (от позвоночника наружу), y, w, h; глубина 1
  private static final float[][][] WING = {
    // Angel: layered tapered feathers, graduated toward the tips for a fuller silhouette.
    {{0,-5,13,3}, {1,-2,14,3}, {2,1,13,3}, {3,4,12,3}, {4,7,10,3}, {5,10,8,3},
     {2,2,3,8}, {5,5,3,8}, {8,8,3,7}, {11,10,2,6}, {0,-7,7,2}, {2,-9,5,2}},
    // Demon: angular upper membrane with layered lower feathers and a pointed outer edge.
    {{0,-6,12,3}, {1,-3,13,4}, {3,1,12,4}, {5,5,10,4}, {7,9,8,4},
     {11,2,3,10}, {9,7,3,9}, {7,11,3,7}, {0,-8,5,2}, {2,-10,4,2}},
    // Butterfly: broad upper and lower lobes with a scalloped, layered edge.
    {{0,-8,9,6}, {2,-6,10,6}, {4,-3,10,6}, {5,1,9,6}, {5,5,8,5}, {4,9,6,4},
     {0,1,6,5}, {1,5,6,5}, {2,9,5,4}, {2,-10,5,3}, {5,-8,5,3}}
  };
  private static ModelPart[] hats = new ModelPart[HAT.length], wings = new ModelPart[WING.length];
  public static ModelPart hat(int i) {
    if (hats[i] == null) {
      ModelData md = new ModelData(); ModelPartBuilder b = ModelPartBuilder.create().uv(0, 0);
      for (float[] q : HAT[i]) b.cuboid(q[0], q[1], q[2], q[3], q[4], q[5]);
      md.getRoot().addChild("hat", b, ModelTransform.NONE);
      hats[i] = TexturedModelData.of(md, 64, 64).createModel().getChild("hat");
    }
    return hats[i];
  }
  private static ModelPart[][] wingParts = new ModelPart[WING.length][2];
  /** side 0 = правое крыло, 1 = левое. Начало координат = точка крепления на спине. */
  public static ModelPart wing(int i, int side) {
    if (wingParts[i][side] == null) {
      float sg = side == 0 ? 1 : -1; ModelData md = new ModelData(); ModelPartBuilder b = ModelPartBuilder.create().uv(0, 0);
      for (float[] q : WING[i]) { float x = sg > 0 ? q[0] : -(q[0] + q[2]); b.cuboid(x, q[1], 0, q[2], q[3], 1); }
      md.getRoot().addChild("w", b, ModelTransform.NONE);
      wingParts[i][side] = TexturedModelData.of(md, 64, 64).createModel().getChild("w");
    }
    return wingParts[i][side];
  }
  public static Identifier hatTex(int i) { return Identifier.of("dobri_visual", "textures/cosmetics/hat_" + i + ".png"); }
  public static Identifier wingTex(int i) { return Identifier.of("dobri_visual", "textures/cosmetics/wings_" + i + ".png"); }
}
