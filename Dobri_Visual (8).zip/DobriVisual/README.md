# Dobri Visual

Fabric client-side visual enhancement mod for Minecraft 1.21.11.

## Visual features
- Liquid Glass menu with rounded translucent panels; trollface badge remains in the lower-right corner.
- The game uses Minecraft's normal UI font (no custom default-font override).
- World Fog and cosmetic Aura/Trail/Orbit effects are client-side visual effects.
- Target ESP highlights nearby living entities with the game's outline pass; range and entity filters are configurable.
- The vanilla sun texture is replaced by a custom glowing sun with animated rays and a subtle pulse.
- Existing HUD editor, keybinds, cosmetics, crosshair, freelook and other visual modules are retained.

## Build
Use Java 21 and run `./gradlew build` (or `gradlew.bat build` on Windows) in a project setup with Gradle available.
