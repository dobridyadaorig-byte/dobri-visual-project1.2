package dev.dobri.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public final class DobriVisualClient implements ClientModInitializer {
    private KeyBinding openMenu;

    private static final int WHITE = 0xFFF4F2FF;
    private static final int MUTED = 0xFFB9A7D7;
    private static final int PANEL = 0xD9161424;
    private static final int PANEL2 = 0xE9211B35;
    private static final int ACCENT = 0xFFB56CFF;
    private static final int GREEN = 0xFF72E6B1;
    private static final int RED = 0xFFFF668E;

    private static long lastTargetSeen = 0L;
    private static String islandMessage = "VISUALS READY";

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.dobri_visual.open_menu",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_RIGHT_SHIFT,
                        KeyBinding.Category.MISC
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen instanceof DobriVisualScreen) {
                    client.setScreen(null);
                } else {
                    client.setScreen(new DobriVisualScreen());
                }
            }
        });

        HudElementRegistry.addLast(
                Identifier.of("dobri_visual", "overlay"),
                (context, tickCounter) ->
                        renderHud(MinecraftClient.getInstance(), context)
        );
    }

    private static void renderHud(MinecraftClient client, DrawContext ctx) {
        if (client.player == null || client.options.hudHidden) {
            return;
        }

        int x = 8;
        int y = 8;

        if (DobriModules.enabled("FPS Counter")) {
            y = panelText(
                    client, ctx,
                    "FPS  " + client.getCurrentFps(),
                    x, y, ACCENT
            );
        }

        if (DobriModules.enabled("Coordinates")) {
            var pos = client.player.getBlockPos();

            y = panelText(
                    client, ctx,
                    "XYZ  " + pos.getX() + "  "
                            + pos.getY() + "  " + pos.getZ(),
                    x, y, WHITE
            );
        }

        if (DobriModules.enabled("Keystrokes")) {
            String keys =
                    (client.options.forwardKey.isPressed() ? "[W]" : " W ") + " " +
                    (client.options.leftKey.isPressed() ? "[A]" : " A ") + " " +
                    (client.options.backKey.isPressed() ? "[S]" : " S ") + " " +
                    (client.options.rightKey.isPressed() ? "[D]" : " D ") + "  " +
                    (client.options.jumpKey.isPressed() ? "[SPACE]" : " SPACE ");

            y = panelText(client, ctx, keys, x, y, WHITE);
        }

        if (DobriModules.enabled("Saturation")) {
            y = panelText(
                    client, ctx,
                    "FOOD  " + client.player.getHungerManager().getFoodLevel() + "/20",
                    x, y, WHITE
            );
        }

        if (DobriModules.enabled("Armor HUD")) {
        StringBuilder armor = new StringBuilder("ARMOR  ");

        for (ItemStack stack : client.player.getInventory().getArmorItems()) {
            if (stack.isEmpty()) {
                armor.append("--  ");
            } else if (stack.isDamageable()) {
                armor.append(
                        Math.max(0, stack.getMaxDamage() - stack.getDamage())
                ).append("  ");
            } else {
                armor.append("OK  ");
            }
        }

        y = panelText(client, ctx, armor.toString(), x, y, MUTED);
        }

        renderDynamicIsland(client, ctx);
        renderTargetHud(client, ctx);
    }

    private static void renderDynamicIsland(
            MinecraftClient client,
            DrawContext ctx
    ) {
        if (!DobriModules.enabled("Dynamic Island")) {
            return;
        }

        int w = 190;
        int h = 28;
        int x = (client.getWindow().getScaledWidth() - w) / 2;
        int y = 12;

        Entity target = currentTarget(client);

        String message = target instanceof LivingEntity
                ? "TARGET LOCKED  •  " + target.getName().getString()
                : islandMessage;

        int tw = client.textRenderer.getWidth(message);

        w = Math.min(
                Math.max(174, tw + 32),
                Math.max(174, client.getWindow().getScaledWidth() - 24)
        );

        x = (client.getWindow().getScaledWidth() - w) / 2;

        ctx.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x553A2455);
        ctx.fill(x, y, x + w, y + h, 0xF30B0D17);

        ctx.fill(
                x + 8, y + 8, x + 12, y + 12,
                target instanceof LivingEntity ? GREEN : ACCENT
        );

        ctx.drawTextWithShadow(
                client.textRenderer,
                message,
                x + 19, y + 10, WHITE
        );
    }

    private static void renderTargetHud(
            MinecraftClient client,
            DrawContext ctx
    ) {
        if (!DobriModules.enabled("Target HUD")) {
            return;
        }

        Entity entity = currentTarget(client);

        if (!(entity instanceof LivingEntity target) || !target.isAlive()) {
            return;
        }

        lastTargetSeen = System.currentTimeMillis();

        String name = target.getName().getString();

        String hp = String.format(
                java.util.Locale.ROOT,
                "%.1f / %.1f HP",
                target.getHealth(),
                target.getMaxHealth()
        );

        int w = Math.max(
                168,
                Math.max(
                        client.textRenderer.getWidth(name),
                        client.textRenderer.getWidth(hp)
                ) + 30
        );

        int x = (client.getWindow().getScaledWidth() - w) / 2;
        int y = client.getWindow().getScaledHeight() / 2 + 34;

        ctx.fill(x - 2, y - 2, x + w + 2, y + 43, 0x663B2054);
        ctx.fill(x, y, x + w, y + 39, PANEL2);
        ctx.fill(x, y, x + 3, y + 39, ACCENT);

        ctx.drawTextWithShadow(
                client.textRenderer, name, x + 10, y + 6, WHITE
        );

        ctx.drawTextWithShadow(
                client.textRenderer, hp, x + 10, y + 19, MUTED
        );

        int barX = x + 10;
        int barY = y + 31;
        int barW = w - 20;

        ctx.fill(barX, barY, barX + barW, barY + 4, 0xFF443047);

        float ratio = Math.max(
                0f,
                Math.min(
                        1f,
                        target.getHealth() / Math.max(1f, target.getMaxHealth())
                )
        );

        ctx.fill(
                barX,
                barY,
                barX + (int) (barW * ratio),
                barY + 4,
                ratio > 0.5f ? GREEN : RED
        );
    }

    private static Entity currentTarget(MinecraftClient client) {
        HitResult hit = client.crosshairTarget;

        if (hit instanceof EntityHitResult entityHit) {
            return entityHit.getEntity();
        }

        return null;
    }

    private static int panelText(
            MinecraftClient client,
            DrawContext ctx,
            String text,
            int x,
            int y,
            int color
    ) {
        int w = client.textRenderer.getWidth(text);

        ctx.fill(x - 4, y - 3, x + w + 5, y + 12, PANEL);
        ctx.fill(x - 4, y - 3, x - 2, y + 12, ACCENT);

        ctx.drawTextWithShadow(
                client.textRenderer, text, x, y, color
        );

        return y + 19;
    }
}