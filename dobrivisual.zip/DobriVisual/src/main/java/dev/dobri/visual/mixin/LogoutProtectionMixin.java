package dev.dobri.visual.mixin;

import dev.dobri.visual.DobriModules;
import dev.dobri.visual.LogoutConfirmationScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Locale;

@Mixin(Screen.class)
public abstract class LogoutProtectionMixin {

    @Inject(
            method = "mouseClicked",
            at = @At("HEAD"),
            cancellable = true
    )
    private void dobri$confirmDisconnect(
            Click click,
            boolean doubled,
            CallbackInfoReturnable<Boolean> cir
    ) {
        Screen screen = (Screen) (Object) this;

        if (!DobriModules.enabled("Logout Protection")) {
            return;
        }

        if (!(screen instanceof GameMenuScreen)) {
            return;
        }

        if (click.button() != 0) {
            return;
        }

        double mouseX = click.x();
        double mouseY = click.y();

        for (var child : screen.children()) {
            if (!(child instanceof ButtonWidget widget)) {
                continue;
            }

            String label = widget.getMessage()
                    .getString()
                    .toLowerCase(Locale.ROOT);

            boolean disconnectButton =
                    label.contains("disconnect")
                    || label.contains("leave server")
                    || label.contains("disconnect and save")
                    || label.contains("выйти")
                    || label.contains("отключиться");

            if (!disconnectButton) {
                continue;
            }

            boolean insideButton =
                    mouseX >= widget.getX()
                    && mouseX < widget.getX() + widget.getWidth()
                    && mouseY >= widget.getY()
                    && mouseY < widget.getY() + widget.getHeight();

            if (insideButton) {
                MinecraftClient.getInstance().setScreen(
                        new LogoutConfirmationScreen(screen)
                );

                cir.setReturnValue(true);
                return;
            }
        }
    }
}
