package dev.dobri.visual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.ArrayList;
import java.util.List;

/** Visual UI prototype. Module switches currently store UI state only. */
public final class DobriVisualScreen extends Screen {
    private static final int BG = 0xE90A0D18, PANEL = 0xF0181C2D, PANEL2 = 0xF021263A;
    private static final int ACCENT = 0xFFB56CFF, FG = 0xFFF4F2FF, MUTED = 0xFF9DA6C2;
    private final List<Entry> entries = new ArrayList<>();
    private String category = "Combat";
    private int scroll;
    private TextFieldWidget protectedNickField;

    public DobriVisualScreen() {
        super(Text.literal("Dobri Visual"));
        add("Combat", "Logout Protection", "Confirm before disconnecting from a server");
        add("Combat", "Hit Particles", "Particles on hit"); add("Combat", "Hit Color", "Tint hurt targets");
        add("Combat", "Kill Effects", "Visual kill effects"); add("Combat", "Target HUD", "Target information panel");
        add("Combat", "Damage Numbers", "Floating damage labels"); add("Combat", "Critical Effects", "Critical hit visuals");
        add("Combat", "Combo Counter", "Consecutive hit counter"); add("Combat", "Projectile Path", "Trajectory preview");
        add("Visual", "Lite Shaders", "Lightweight visual preset; Iris needed for real shaders");
        add("HUD", "Coordinates", "Position and direction"); add("HUD", "FPS Counter", "Frames per second");
        add("HUD", "Armor HUD", "Armor durability display"); add("HUD", "Keystrokes", "Pressed movement keys");
        add("HUD", "Inventory HUD", "Inventory status panel"); add("HUD", "Saturation", "Food information");
        add("HUD", "Custom Crosshair", "Crosshair styles"); add("HUD", "Dynamic Island", "Top-center live status pill");
        add("Items", "Shulker Preview", "Preview container contents"); add("Items", "Item Physics", "Dropped item presentation");
        add("Items", "Item Swap", "Item swap indicator");
        add("Chat", "Chat Helper", "Chat convenience controls"); add("Chat", "Chat History", "Recent messages"); add("Chat", "Anti Spam", "Client-side chat filtering");
        add("Automation", "Auto Eat", "Automatic eating helper"); add("Automation", "Auto Potion", "Potion helper");
        add("Automation", "Auto Reconnect", "Reconnect helper"); add("Automation", "Auto Respawn", "Respawn helper");
        add("Automation", "Auto Fish", "Fishing helper"); add("Automation", "Fast XP", "Experience bottle helper");
        add("Extras", "Streamer Mode", "Hide selected screen information"); add("Extras", "Anarchy Finder", "Server information helper"); add("Extras", "Friends", "Local friend labels");
        add("Cosmetics", "Wings", "Cosmetic wings"); add("Cosmetics", "Capes", "Cosmetic capes");
        add("Cosmetics", "Backpacks", "Cosmetic backpacks"); add("Cosmetics", "Hats", "Cosmetic hats"); add("Cosmetics", "Pets", "Cosmetic companions");
        add("Utility", "Protect Mode", "Replace your nickname locally in TAB/player list");
        add("Utility", "Inventory Walk", "Walk while inventory is open"); add("Utility", "Auto Tool", "Select tool for the targeted block");
        add("Utility", "Notifications", "Client-side status notifications"); add("Utility", "HUD Editor", "Configure HUD positions"); add("Utility", "Config Profiles", "Manage local visual presets");
    }
    private void add(String group, String name, String desc) { entries.add(new Entry(group, name, desc)); }

    @Override protected void init() {
        int x = Math.max(8, (width - 760) / 2), y = Math.max(8, (height - 460) / 2);
        String[] tabs = {"Combat", "Visual", "HUD", "Items", "Chat", "Automation", "Extras", "Cosmetics", "Utility"};
        for (int i = 0; i < tabs.length; i++) {
            String tab = tabs[i];
            addDrawableChild(ButtonWidget.builder(Text.literal((tab.equals(category) ? "◆  " : "◇  ") + tab), b -> { category = tab; scroll = 0; clearAndInit(); })
                    .dimensions(x + 18, y + 90 + i * 34, 142, 28).build());
        }
        if (category.equals("Utility")) {
            protectedNickField = new TextFieldWidget(textRenderer, x + 465, y + 78, 250, 24, Text.literal("Replacement nickname"));
            protectedNickField.setMaxLength(16);
            protectedNickField.setText(DobriModules.protectedNickname());
            protectedNickField.setChangedListener(DobriModules::setProtectedNickname);
            addDrawableChild(protectedNickField);
        }
        int index = 0;
        for (Entry e : entries) {
            if (!e.group.equals(category)) continue;
            int rowY = y + 120 + index * 54 - scroll; index++;
            if (rowY < y + 68 || rowY > y + 425) continue;
            Entry selected = e;
            selected.enabled = DobriModules.enabled(selected.name);
            addDrawableChild(ButtonWidget.builder(Text.literal(selected.enabled ? "ON" : "OFF"), b -> { selected.enabled = !selected.enabled; DobriModules.set(selected.name, selected.enabled); if (selected.name.equals("Lite Shaders")) DobriModules.applyLiteShaders(net.minecraft.client.MinecraftClient.getInstance(), selected.enabled); clearAndInit(); })
                    .dimensions(x + 665, rowY + 5, 58, 26).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(x + 660, y + 420, 76, 26).build());
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int x = Math.max(8, (width - 760) / 2), y = Math.max(8, (height - 460) / 2), r = x + 760, b = y + 460;
        ctx.fill(0, 0, width, height, 0x99040810); ctx.fill(x, y, r, b, BG); ctx.fill(x, y, r, y + 4, ACCENT);
        ctx.fill(x + 12, y + 12, x + 174, b - 12, PANEL); ctx.fill(x + 182, y + 72, r - 12, b - 12, PANEL);
        ctx.fill(x + 190, y + 80, r - 20, y + 112, PANEL2);
        ctx.drawTextWithShadow(textRenderer, Text.literal("DOBRI").formatted(Formatting.BOLD, Formatting.LIGHT_PURPLE), x + 22, y + 22, FG);
        ctx.drawTextWithShadow(textRenderer, Text.literal("VISUAL  /  CLIENT EXPERIENCE"), x + 22, y + 42, MUTED);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Visuals, your way."), x + 192, y + 26, FG);
        ctx.drawTextWithShadow(textRenderer, Text.literal("RIGHT SHIFT  •  SETTINGS"), x + 192, y + 46, MUTED);
        ctx.drawTextWithShadow(textRenderer, Text.literal(category.toUpperCase()), x + 202, y + 91, ACCENT);
        int row = y + 120;
        for (Entry e : entries) {
            if (!e.group.equals(category)) continue;
            int ry = row - scroll; row += 54;
            if (ry < y + 68 || ry > b - 35) continue;
            ctx.fill(x + 192, ry, r - 22, ry + 44, PANEL2); ctx.fill(x + 192, ry, x + 195, ry + 44, e.enabled ? ACCENT : 0xFF39415B);
            ctx.drawTextWithShadow(textRenderer, Text.literal(e.name), x + 205, ry + 7, FG);
            ctx.drawTextWithShadow(textRenderer, Text.literal(e.desc), x + 205, ry + 23, MUTED);
        }
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawTextWithShadow(textRenderer, Text.literal(category.equals("Utility") ? "RIGHT-CLICK PROTECT MODE ROW TO EDIT NICK" : category.equals("Visual") ? "LITE SHADERS = PERFORMANCE PRESET; REAL SHADERS REQUIRE IRIS + A SHADER PACK" : "LIVE: FPS / COORDS / KEYS / FOOD / ARMOR / TARGET HUD / DYNAMIC ISLAND"), x + 22, b - 28, MUTED);
    }
    // Right-click editing was removed here because Minecraft 1.21.11 changed the GUI click API.
    // The module screen remains usable with the standard widget/input handling.
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(scroll + (verticalAmount > 0 ? -54 : 54), 540)); clearAndInit(); return true;
    }
    @Override public boolean shouldPause() { return false; }
    private static final class Entry {
        final String group, name, desc; boolean enabled;
        Entry(String group, String name, String desc) { this.group = group; this.name = name; this.desc = desc; }
    }
}
