package dev.dobri.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Confirmation shown before disconnecting from a multiplayer server. */
public final class LogoutConfirmationScreen extends Screen {
    private final Screen parent;
    private static final int PURPLE = 0xFFB56CFF;
    private static final int WHITE = 0xFFF4F2FF;
    private static final int MUTED = 0xFFB9A7D7;

    public LogoutConfirmationScreen(Screen parent) {
        super(Text.literal("Confirm disconnect"));
        this.parent = parent;
    }

    @Override protected void init() {
        int center = width / 2;
        int y = height / 2 + 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Disconnect"), b -> {
            MinecraftClient client = MinecraftClient.getInstance();
            client.disconnect(Text.literal("Disconnected from server"));
            client.setScreen(new TitleScreen());
        }).dimensions(center - 105, y, 100, 26).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Stay"), b -> close()).dimensions(center + 5, y, 100, 26).build());
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int w = Math.min(360, width - 24), h = 112;
        int x = (width - w) / 2, y = (height - h) / 2;
        ctx.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x663D2059);
        ctx.fill(x, y, x + w, y + h, 0xF00D101C);
        ctx.fill(x, y, x + w, y + 3, PURPLE);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("LEAVE SERVER?").formatted(Formatting.BOLD, Formatting.LIGHT_PURPLE), width / 2, y + 15, WHITE);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Confirm that you want to disconnect."), width / 2, y + 38, MUTED);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("This only prevents accidental clicks."), width / 2, y + 52, MUTED);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
