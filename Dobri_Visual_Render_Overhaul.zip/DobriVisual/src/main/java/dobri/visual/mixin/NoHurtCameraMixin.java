package dobri.visual.mixin;

import dobri.visual.module.ModuleManager;
import dobri.visual.module.Module;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class NoHurtCameraMixin {
  @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
  private void dobri$disableHurtTilt(MatrixStack matrices, CallbackInfo ci) {
    Module m = ModuleManager.get("No Hurt Camera");
    if (m != null && m.isEnabled()) ci.cancel();
  }
}
