package dobri.visual.module;
import dobri.visual.config.Config;
import dobri.visual.gui.HudEditorScreen;
import dobri.visual.module.impl.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
public class ModuleManager {
  public static final List<Module> MODULES = new ArrayList<>();
  private static final long START = System.currentTimeMillis();
  public static final String[] CATEGORIES = {"Combat Visuals", "Render", "World", "HUD", "Movement", "Cosmetics", "Settings"};
  public static void init() {
    var mc = MinecraftClient.getInstance();
    MODULES.add(new ColorFilter()); MODULES.add(new FogHaze()); MODULES.add(new CustomCrosshair()); MODULES.add(new TargetEsp());
    MODULES.add(new TextHud("FPS", "HUD", "Счётчик FPS", true, 6, 6, () -> mc.getCurrentFps() + " FPS"));
    MODULES.add(new TextHud("Coordinates", "HUD", "Координаты X Y Z", true, 6, 22, () -> mc.player == null ? null : String.format("XYZ %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ())));
    MODULES.add(new TextHud("Direction", "HUD", "Сторона света", false, 6, 38, () -> mc.player == null ? null : mc.player.getHorizontalFacing().asString()));
    MODULES.add(new TextHud("Clock", "HUD", "Системное время", false, 6, 54, () -> LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
    MODULES.add(new TextHud("Session Timer", "HUD", "Время сессии", false, 6, 70, () -> { long s = (System.currentTimeMillis() - START) / 1000; return String.format("%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60); }));
    MODULES.add(new TextHud("Speed", "HUD", "Скорость (блоков/с)", false, 6, 86, () -> mc.player == null ? null : String.format("%.2f b/s", Math.hypot(mc.player.getX() - mc.player.lastX, mc.player.getZ() - mc.player.lastZ) * 20)));
    MODULES.add(new TextHud("CPS", "HUD", "Клики в секунду (ЛКМ | ПКМ)", false, 6, 102, ClickTracker::text));
    MODULES.add(new ArmorHud()); MODULES.add(new Keystrokes()); MODULES.add(new TargetHud());
    MODULES.add(new Freelook()); MODULES.add(new AutoArmor()); MODULES.add(new NoRender()); MODULES.add(new dobri.visual.module.impl.NoHurtCamera());
    MODULES.add(new ModelCosmetic("Hat", false)); MODULES.add(new ModelCosmetic("Wings", true));
    MODULES.add(new JumpCircle());
    MODULES.add(new CosmeticFx("Particles", CosmeticFx.Mode.PARTICLES, "Частицы вокруг персонажа (звёзды, сердца, снежинки, искры)"));
    MODULES.add(new CosmeticFx("Aura", CosmeticFx.Mode.AURA, "Цветная аура"));
    MODULES.add(new CosmeticFx("Trail", CosmeticFx.Mode.TRAIL, "След при движении"));
    MODULES.add(new CosmeticFx("Orbits", CosmeticFx.Mode.ORBITS, "Орбиты вокруг игрока"));
    for (Module m : MODULES) m.loadPos();
  }
  public static Module get(String n) { for (Module m : MODULES) if (m.name.equals(n)) return m; return null; }
  public static List<Module> byCategory(String c) { List<Module> l = new ArrayList<>(); for (Module m : MODULES) if (m.category.equals(c)) l.add(m); return l; }
  public static List<Module> hudModules() { List<Module> l = new ArrayList<>(); for (Module m : MODULES) if (m.hud) l.add(m); return l; }
  public static void resetPositions() { Config.pos.clear(); for (Module m : MODULES) { m.x = m.dx; m.y = m.dy; } Config.save(); }
  public static void tick(MinecraftClient mc) {
    Config.flush();
    if (mc.player == null) return;
    long win = mc.getWindow().getHandle();
    for (Module m : MODULES) {
      try {
        int k = m.key();
        boolean down = k >= 0 && mc.currentScreen == null && GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
        if (m.hold) m.keyDown = down; else { if (down && !m.keyDown) m.toggle(); m.keyDown = down; }
        m.onTick();
      } catch (Throwable t) { System.err.println("[DobriVisual] " + m.name + " tick: " + t); }
    }
  }
  public static void renderHud(DrawContext ctx) {
    var mc = MinecraftClient.getInstance();
    if (mc.options.hudHidden) return;
    ClickTracker.poll();
    boolean editor = mc.currentScreen instanceof HudEditorScreen;
    for (Module m : MODULES) if (m.isEnabled() && !(editor && m.hud)) {
      try { m.render(ctx); } catch (Throwable t) { System.err.println("[DobriVisual] " + m.name + ": " + t); }
    }
  }
}
