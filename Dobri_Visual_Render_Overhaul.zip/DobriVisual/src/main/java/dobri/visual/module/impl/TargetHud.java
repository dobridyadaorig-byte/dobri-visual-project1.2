package dobri.visual.module.impl;

import dobri.visual.gui.Draw;
import dobri.visual.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Compact glass target panel for the entity under the crosshair. */
public final class TargetHud extends Module {
  public TargetHud() {
    super("Target HUD", "HUD", "Полупрозрачная карточка цели под прицелом", true, 8, 128);
    hud = true;
    num("Width", 150, 120, 220);
    bool("Show Health", true);
    bool("Rainbow", false);
    num("Hue", 265, 0, 360);
  }

  @Override public void render(DrawContext c) {
    if (mc.player == null || mc.world == null || !(mc.crosshairTarget instanceof EntityHitResult hit)
        || !(hit.getEntity() instanceof LivingEntity target) || target == mc.player || !target.isAlive()) return;
    int w = (int)n("Width"), h = b("Show Health") ? 44 : 30;
    int px = Math.max(4, Math.min(this.x, mc.getWindow().getScaledWidth() - w - 4));
    int py = Math.max(4, Math.min(this.y, mc.getWindow().getScaledHeight() - h - 4));
    int accent = b("Rainbow") ? java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 6000) / 6000f, .75f, 1f) : java.awt.Color.HSBtoRGB((float)n("Hue") / 360f, .8f, 1f);
    Draw.panel(c, px, py, w, h, 10, 0xB91A1B29, true);
    Draw.round(c, px + 7, py + 7, 5, 5, 2, accent | 0xFF000000);
    String name = target.getName().getString();
    int maxName = w - 22;
    c.drawText(mc.textRenderer, mc.textRenderer.trimToWidth(name, maxName), px + 17, py + 6, 0xFFF5F5FF, true);
    if (b("Show Health")) {
      float max = Math.max(1f, target.getMaxHealth());
      float hp = Math.max(0f, Math.min(1f, target.getHealth() / max));
      c.drawText(mc.textRenderer, String.format(java.util.Locale.ROOT, "%.1f / %.1f HP", target.getHealth(), max), px + 8, py + 20, 0xFFD7D7E8, false);
      Draw.round(c, px + 8, py + 33, w - 16, 5, 2, 0xFF373746);
      if (hp > 0) Draw.round(c, px + 8, py + 33, Math.max(2, (int)((w - 16) * hp)), 5, 2, hp > .5f ? 0xFF63E6A5 : hp > .25f ? 0xFFFFC857 : 0xFFFF647C);
    }
  }
}
