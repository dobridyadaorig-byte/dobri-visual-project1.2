package dobri.visual.module.impl;

import dobri.visual.module.Module;

/** Disables the first-person hurt tilt without changing damage or knockback. */
public final class NoHurtCamera extends Module {
  public NoHurtCamera() {
    super("No Hurt Camera", "Render", "Отключает визуальную тряску камеры при получении урона", false, 0, 0);
  }
}
