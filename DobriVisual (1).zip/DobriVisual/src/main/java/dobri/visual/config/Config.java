package dobri.visual.config;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
public class Config {
  public static class Data {
    int menuKey = 344; int theme = 0;
    Map<String,Boolean> enabled = new LinkedHashMap<>();
    Map<String,Double> settings = new LinkedHashMap<>();
    Map<String,Integer> keys = new LinkedHashMap<>();
    Map<String,int[]> pos = new LinkedHashMap<>();
  }
  public static int menuKey = 344, theme = 0;
  public static Map<String,Boolean> enabled = new LinkedHashMap<>();
  public static Map<String,Double> settings = new LinkedHashMap<>();
  public static Map<String,Integer> keys = new LinkedHashMap<>();
  public static Map<String,int[]> pos = new LinkedHashMap<>();
  private static volatile boolean dirty;
  private static final Gson G = new GsonBuilder().setPrettyPrinting().create();
  public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("dobri_visual"); }
  private static Path file() { return dir().resolve("config.json"); }
  public static void load() { load(file()); }
  public static void load(Path f) {
    try {
      if (!Files.exists(f)) return;
      Data d = G.fromJson(Files.readString(f), Data.class);
      if (d == null) return;
      menuKey = d.menuKey; theme = d.theme;
      if (d.enabled != null) enabled = d.enabled; if (d.settings != null) settings = d.settings;
      if (d.keys != null) keys = d.keys; if (d.pos != null) pos = d.pos;
    } catch (Exception ex) {
      System.err.println("[DobriVisual] config повреждён, сброс к значениям по умолчанию: " + ex);
      try { Files.copy(f, f.resolveSibling(f.getFileName() + ".bak"), StandardCopyOption.REPLACE_EXISTING); } catch (Exception ignored) {}
    }
  }
  private static String json() {
    Data d = new Data(); d.menuKey = menuKey; d.theme = theme;
    d.enabled = new LinkedHashMap<>(enabled); d.settings = new LinkedHashMap<>(settings);
    d.keys = new LinkedHashMap<>(keys); d.pos = new LinkedHashMap<>(pos);
    return G.toJson(d);
  }
  public static void save() { dirty = true; }
  public static void dirty() { dirty = true; }
  /** Вызывается из тика: запись файла идёт в отдельном потоке. */
  public static void flush() {
    if (!dirty) return; dirty = false;
    String s = json();
    new Thread(() -> { try { Files.createDirectories(dir()); Files.writeString(file(), s); } catch (Exception e) { e.printStackTrace(); } }, "dobri-config").start();
  }
  /** Экспорт профиля в config/dobri_visual/profiles/<name>.json */
  public static void exportProfile(String name) { try { Files.createDirectories(dir().resolve("profiles")); Files.writeString(dir().resolve("profiles").resolve(name + ".json"), json()); } catch (Exception e) { e.printStackTrace(); } }
  public static void importProfile(String name) { load(dir().resolve("profiles").resolve(name + ".json")); save(); }
  public static void reset() { enabled.clear(); settings.clear(); keys.clear(); pos.clear(); menuKey = 344; theme = 0; save(); }
}
