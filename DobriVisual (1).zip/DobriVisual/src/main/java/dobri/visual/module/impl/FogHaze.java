package dobri.visual.module.impl;
import net.minecraft.client.gui.DrawContext;
public class FogHaze extends dobri.visual.module.Module {
  public FogHaze() {
    super("Fog Haze", "World", "Цветная дымка по краям экрана (имитация тумана, не меняет настоящий туман)", false, 0, 0);
    num("Density", 40, 0, 100); num("Hue", 210, 0, 360); bool("Rainbow", false);
  }
  @Override public void render(DrawContext c) {
    int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight(); int a = (int) (n("Density") * 1.8); int col = Fx.rgb(this);
    int full = (a << 24) | col, none = col;
    c.fillGradient(0, 0, w, h / 3, full, none); c.fillGradient(0, h * 2 / 3, w, h, none, full);
  }
}
