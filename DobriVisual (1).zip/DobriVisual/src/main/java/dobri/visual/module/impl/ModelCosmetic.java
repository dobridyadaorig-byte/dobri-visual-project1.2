package dobri.visual.module.impl;
import dobri.visual.cosmetics.CosmeticModels;
public class ModelCosmetic extends dobri.visual.module.Module {
  public ModelCosmetic(String name, boolean wings) {
    super(name, "Cosmetics", wings ? "3D-крылья на спине (видишь только ты, лучше в третьем лице — F5)" : "3D-шляпа на голове (видишь только ты, лучше в третьем лице — F5)", false, 0, 0);
    num("Style", 0, 0, (wings ? CosmeticModels.WINGS : CosmeticModels.HATS).length - 1).labeled(wings ? CosmeticModels.WINGS : CosmeticModels.HATS);
    num("Scale", 1.0, 0.6, 1.6);
    if (wings) num("Flap", 20, 0, 40);
  }
}
