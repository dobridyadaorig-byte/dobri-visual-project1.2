package com.dobri.visual.module.modules;
import com.dobri.visual.module.*; import net.minecraft.client.MinecraftClient;
public final class FullbrightModule extends ClientModule {
 private double oldGamma=1.0;
 public FullbrightModule(){super("Fullbright","Raises client gamma while enabled.",ModuleCategory.VISUALS);}
 @Override protected void onEnable(){var o=MinecraftClient.getInstance().options;oldGamma=o.getGamma().getValue();o.getGamma().setValue(15.0);}
 @Override protected void onDisable(){MinecraftClient.getInstance().options.getGamma().setValue(oldGamma);}
}
