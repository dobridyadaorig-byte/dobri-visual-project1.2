package com.dobri.visual.module;

import net.minecraft.client.MinecraftClient;

public abstract class ClientModule {
    private final String name, description;
    private final ModuleCategory category;
    private boolean enabled;
    private double value = 1.0;

    protected ClientModule(String name, String description, ModuleCategory category) {
        this.name = name; this.description = description; this.category = category;
    }
    public String name() { return name; }
    public String description() { return description; }
    public ModuleCategory category() { return category; }
    public boolean enabled() { return enabled; }
    public double value() { return value; }
    public void value(double v) { value = Math.max(0, Math.min(1, v)); onValueChanged(); }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean state) {
        if (enabled == state) return;
        enabled = state;
        if (state) onEnable(); else onDisable();
    }
    protected void onEnable() {}
    protected void onDisable() {}
    protected void onValueChanged() {}
    public void tick(MinecraftClient client) {}
}
