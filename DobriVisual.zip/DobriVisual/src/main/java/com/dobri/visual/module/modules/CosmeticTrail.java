package com.dobri.visual.module.modules;
import com.dobri.visual.module.*;
public final class CosmeticTrail extends ClientModule { public CosmeticTrail(){super("Player Trails","Cosmetic trail renderer is not implemented in this version.",ModuleCategory.COSMETICS);} }
