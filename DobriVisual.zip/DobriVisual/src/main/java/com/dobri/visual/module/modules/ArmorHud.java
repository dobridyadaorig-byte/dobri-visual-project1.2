package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class ArmorHud extends HudModule {
 public ArmorHud(){super("Armor Status","Shows equipped armor durability.");}
 public void render(MinecraftClient c, DrawContext d){if(c.player!=null){int y=56;for(var stack:c.player.getArmorItems()){if(!stack.isEmpty()){String s=stack.getName().getString();if(stack.isDamageable())s+=" §d"+(stack.getMaxDamage()-stack.getDamage())+"";text(c,d,s,8,y);y+=12;}}}}
}
