package com.dobri.visual.ui;

import com.dobri.visual.DobriVisualClient;
import com.dobri.visual.module.ClientModule;
import com.dobri.visual.module.ModuleCategory;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class DobriScreen extends Screen {
    private ModuleCategory category = ModuleCategory.VISUALS;
    private String search = "";
    private ClientModule selected;
    private double openAnim = 0;
    private static final int BG = 0xF20B0C12, PANEL = 0xFF12141D, CARD = 0xFF1A1D29, CARD_HOVER = 0xFF25283A;
    private static final int PURPLE = 0xFF9D70FF, TEXT = 0xFFF2F0FF, MUTED = 0xFF9295AA;

    public DobriScreen() { super(Text.literal("DOBRI VISUAL")); }
    @Override public boolean shouldPause() { return false; }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        openAnim = Math.min(1.0, openAnim + delta * 3.8);
        ctx.fill(0, 0, width, height, 0x9906070B);
        int w = Math.min(760, width - 36), h = Math.min(470, height - 30);
        int x = (width-w)/2, y=(height-h)/2;
        ctx.fill(x+3,y+4,x+w+3,y+h+4,0x55000000);
        ctx.fill(x,y,x+w,y+h,BG);
        ctx.fill(x,y,x+174,y+h,PANEL);
        ctx.fill(x,y,x+w,y+68,0xFF10121A);
        ctx.fill(x,y+67,x+w,y+68,0xFF292B3A);
        ctx.fill(x+18,y+17,x+48,y+47,0xFF302448);
        ctx.drawText(textRenderer,"D",x+28,y+25,PURPLE,false);
        ctx.drawText(textRenderer,"DOBRI VISUAL",x+58,y+19,TEXT,false);
        ctx.drawText(textRenderer,"CLIENT  /  1.0.0",x+58,y+36,MUTED,false);
        ctx.drawText(textRenderer,"RIGHT SHIFT  ·  MENU",x+w-170,y+28,MUTED,false);
        ctx.fill(x+14,y+82,x+160,y+108,0xFF1B1D29);
        ctx.drawText(textRenderer,"⌕  "+(search.isEmpty()?"Search modules":search),x+24,y+91,search.isEmpty()?MUTED:TEXT,false);
        int cy=y+124;
        for(ModuleCategory cat:ModuleCategory.values()) {
            boolean active=cat==category; int rowY=cy;
            if(active) { ctx.fill(x+12,rowY-5,x+162,rowY+22,0xFF302448);ctx.fill(x+12,rowY-5,x+15,rowY+22,PURPLE); }
            ctx.drawText(textRenderer,cat.title,x+25,rowY+3,active?TEXT:MUTED,false);
            long count=DobriVisualClient.MODULES.in(cat).size();
            ctx.drawText(textRenderer,""+count,x+139,rowY+3,active?PURPLE:MUTED,false);
            cy+=34;
        }
        ctx.drawText(textRenderer,"DOBRI  •  BETA",x+18,y+h-28,MUTED,false);
        ctx.drawText(textRenderer,"MODULES",x+194,y+84,MUTED,false);
        List<ClientModule> visible = DobriVisualClient.MODULES.in(category).stream().filter(m->m.name().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))||m.description().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))).toList();
        int gridX=x+194, gridY=y+110, cardW=(w-218)/2, cardH=68, gap=10;
        for(int i=0;i<visible.size();i++) {
            ClientModule m=visible.get(i); int col=i%2,row=i/2;
            int bx=gridX+col*(cardW+gap), by=gridY+row*(cardH+10);
            if(by+cardH>y+h-18) continue;
            boolean hover=mouseX>=bx&&mouseX<=bx+cardW&&mouseY>=by&&mouseY<=by+cardH;
            ctx.fill(bx,by,bx+cardW,by+cardH,hover?CARD_HOVER:CARD);
            ctx.fill(bx,by,bx+3,by+cardH,m.enabled()?PURPLE:0xFF343746);
            ctx.drawText(textRenderer,m.name(),bx+13,by+12,TEXT,false);
            String desc=m.description(); if(desc.length()>34)desc=desc.substring(0,31)+"...";
            ctx.drawText(textRenderer,desc,bx+13,by+29,MUTED,false);
            int sx=bx+cardW-38, sy=by+14;
            ctx.fill(sx,sy,sx+25,sy+14,m.enabled()?0xFF8159D9:0xFF383B49);
            ctx.fill(sx+(m.enabled()?13:2),sy+2,sx+(m.enabled()?23:12),sy+12,0xFFF5F2FF);
            ctx.drawText(textRenderer,m.enabled()?"ON":"OFF",bx+cardW-40,by+44,m.enabled()?PURPLE:MUTED,false);
        }
        if(selected!=null) {
            int px=x+w-204, py=y+82;
            ctx.fill(px,py,x+w-14,y+h-18,0xFF171923);
            ctx.drawText(textRenderer,"MODULE SETTINGS",px+12,py+13,MUTED,false);
            ctx.drawText(textRenderer,selected.name(),px+12,py+34,TEXT,false);
            ctx.drawText(textRenderer,selected.enabled()?"Enabled":"Disabled",px+12,py+52,selected.enabled()?PURPLE:MUTED,false);
            ctx.drawText(textRenderer,"Value",px+12,py+80,MUTED,false);
            ctx.fill(px+12,py+102,x+w-26,py+106,0xFF3A3D4D);
            ctx.fill(px+12,py+102,(int)(px+12+(x+w-38- px-12)*selected.value()),py+106,PURPLE);
            ctx.drawText(textRenderer,String.format(Locale.ROOT,"%.0f%%",selected.value()*100),px+12,py+114,TEXT,false);
            ctx.drawText(textRenderer,"Click card to toggle",px+12,py+146,MUTED,false);
        }
        ctx.drawText(textRenderer,"ESC  CLOSE",x+w-92,y+h-24,MUTED,false);
        super.render(ctx,mouseX,mouseY,delta);
    }

    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        int w=Math.min(760,width-36),h=Math.min(470,height-30),x=(width-w)/2,y=(height-h)/2;
        if(button==0) {
            if(mouseY>=y+82&&mouseY<=y+108&&mouseX>=x+14&&mouseX<=x+160){search=search.isEmpty()?"":search;return true;}
            int cy=y+124;
            for(ModuleCategory cat:ModuleCategory.values()){if(mouseY>=cy-5&&mouseY<=cy+22&&mouseX>=x+12&&mouseX<=x+162){category=cat;selected=null;return true;}cy+=34;}
            int cardW=(w-218)/2,cardH=68,gap=10,gridX=x+194,gridY=y+110;
            List<ClientModule> visible=DobriVisualClient.MODULES.in(category).stream().filter(m->m.name().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))||m.description().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))).toList();
            for(int i=0;i<visible.size();i++){ClientModule m=visible.get(i);int bx=gridX+(i%2)*(cardW+gap),by=gridY+(i/2)*(cardH+10);if(mouseX>=bx&&mouseX<=bx+cardW&&mouseY>=by&&mouseY<=by+cardH){m.toggle();selected=m;DobriVisualClient.saveConfig();return true;}}
            if(selected!=null){int px=x+w-204,py=y+82;if(mouseX>=px+12&&mouseX<=x+w-26&&mouseY>=py+98&&mouseY<=py+112){selected.value(Math.max(0,Math.min(1,(mouseX-(px+12))/(double)(w-230))));DobriVisualClient.saveConfig();return true;}}
        }
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public boolean charTyped(char chr,int modifiers){if(!Character.isISOControl(chr)&&search.length()<32){search+=chr;return true;}return super.charTyped(chr,modifiers);}
    @Override public boolean keyPressed(int keyCode,int scanCode,int modifiers){if(keyCode==GLFW.GLFW_KEY_BACKSPACE&&!search.isEmpty()){search=search.substring(0,search.length()-1);return true;}if(keyCode==GLFW.GLFW_KEY_ESCAPE){close();return true;}return super.keyPressed(keyCode,scanCode,modifiers);}
    @Override public void close(){DobriVisualClient.saveConfig();if(client!=null)client.setScreen(null);}
}
