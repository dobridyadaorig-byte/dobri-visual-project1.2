package com.dobri.visual.module;

import com.dobri.visual.module.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.*;

public final class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();
    public ModuleManager() {
        modules.add(new FpsCounter());
        modules.add(new CoordinatesHud());
        modules.add(new SprintModule());
        modules.add(new ZoomModule());
        modules.add(new FullbrightModule());
        modules.add(new CrosshairModule());
        modules.add(new KeystrokesHud());
        modules.add(new PingHud());
        modules.add(new ArmorHud());
        modules.add(new SessionHud());
        modules.add(new WorldInfoHud());
        modules.add(new ParticleLimiter());
        modules.add(new CosmeticTrail());
        modules.add(new StreamerMode());
    }
    public List<ClientModule> all() { return Collections.unmodifiableList(modules); }
    public List<ClientModule> in(ModuleCategory category) { return modules.stream().filter(m -> m.category() == category).toList(); }
    public Optional<ClientModule> byName(String name) { return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst(); }
    public void tick(MinecraftClient client) { modules.forEach(m -> m.tick(client)); }
    public void renderHud(MinecraftClient client, DrawContext context) {
        for (ClientModule module : modules) if (module.enabled() && module instanceof HudModule hud) hud.render(client, context);
    }
}
