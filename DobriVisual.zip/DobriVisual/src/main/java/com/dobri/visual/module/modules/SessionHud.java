package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class SessionHud extends HudModule {
 public SessionHud(){super("Session Information","Shows world or server context.");}
 public void render(MinecraftClient c, DrawContext d){if(c.world!=null)text(c,d,"WORLD  §d"+c.world.getRegistryKey().getValue().getPath(),8,104);}
}
