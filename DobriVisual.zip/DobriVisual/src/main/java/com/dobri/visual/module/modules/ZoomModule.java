package com.dobri.visual.module.modules;
import com.dobri.visual.module.*; import net.minecraft.client.MinecraftClient;
public final class ZoomModule extends ClientModule {
 private int oldFov=70;
 public ZoomModule(){super("Zoom","Hold module enabled to zoom; restores your FOV when disabled.",ModuleCategory.VISUALS);}
 @Override protected void onEnable(){MinecraftClient c=MinecraftClient.getInstance();oldFov=c.options.getFov().getValue();c.options.getFov().setValue(30);}
 @Override protected void onDisable(){MinecraftClient c=MinecraftClient.getInstance();c.options.getFov().setValue(oldFov);}
}
