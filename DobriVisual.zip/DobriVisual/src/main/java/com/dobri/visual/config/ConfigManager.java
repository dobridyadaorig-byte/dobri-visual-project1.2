package com.dobri.visual.config;

import com.dobri.visual.module.ClientModule;
import com.dobri.visual.module.ModuleManager;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class ConfigManager {
    private final Path path = FabricLoader.getInstance().getConfigDir().resolve("dobrivisual.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public void load(ModuleManager manager) {
        if (!Files.exists(path)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject modules = root.has("modules") && root.get("modules").isJsonObject() ? root.getAsJsonObject("modules") : new JsonObject();
            for (ClientModule module : manager.all()) {
                JsonElement el = modules.get(module.name());
                if (el == null || !el.isJsonObject()) continue;
                JsonObject data = el.getAsJsonObject();
                if (data.has("value") && data.get("value").isJsonPrimitive()) module.value(data.get("value").getAsDouble());
                if (data.has("enabled") && data.get("enabled").isJsonPrimitive()) module.setEnabled(data.get("enabled").getAsBoolean());
            }
        } catch (Exception e) {
            System.err.println("[DOBRI VISUAL] Config could not be loaded; using defaults: " + e.getMessage());
            try { Files.move(path, path.resolveSibling("dobrivisual.json.broken"), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) { }
        }
    }

    public void save(ModuleManager manager) {
        JsonObject root = new JsonObject(), modules = new JsonObject();
        for (ClientModule module : manager.all()) {
            JsonObject data = new JsonObject(); data.addProperty("enabled", module.enabled()); data.addProperty("value", module.value());
            modules.add(module.name(), data);
        }
        root.addProperty("schema", 1); root.add("modules", modules);
        try {
            Files.createDirectories(path.getParent());
            Path tmp = path.resolveSibling(path.getFileName() + ".tmp");
            Files.writeString(tmp, gson.toJson(root), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { System.err.println("[DOBRI VISUAL] Config save failed: " + e.getMessage()); }
    }
}
