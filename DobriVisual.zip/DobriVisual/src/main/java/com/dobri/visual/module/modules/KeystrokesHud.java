package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class KeystrokesHud extends HudModule {
 public KeystrokesHud(){super("Keystrokes","Shows movement key state.");}
 public void render(MinecraftClient c, DrawContext d){if(c.player!=null){String s=(c.options.forwardKey.isPressed()?"§dW":"§7W")+"  "+(c.options.leftKey.isPressed()?"§dA":"§7A")+"  "+(c.options.backKey.isPressed()?"§dS":"§7S")+"  "+(c.options.rightKey.isPressed()?"§dD":"§7D");text(c,d,s,8,32);}}
}
