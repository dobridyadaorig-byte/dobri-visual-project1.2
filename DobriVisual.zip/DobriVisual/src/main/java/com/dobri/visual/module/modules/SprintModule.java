package com.dobri.visual.module.modules;
import com.dobri.visual.module.*; import net.minecraft.client.MinecraftClient;
public final class SprintModule extends ClientModule {
 public SprintModule(){super("Sprint","Automatically keeps sprint active when moving forward.",ModuleCategory.PLAYER);}
 @Override public void tick(MinecraftClient c){if(enabled()&&c.player!=null&&c.options.forwardKey.isPressed()&&!c.player.isSneaking())c.player.setSprinting(true);}
}
