package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class CoordinatesHud extends HudModule {
 public CoordinatesHud(){super("Coordinates","Shows player coordinates.");}
 public void render(MinecraftClient c, DrawContext d){if(c.player!=null){var p=c.player.getBlockPos();text(c,d,"XYZ  §d"+p.getX()+"  "+p.getY()+"  "+p.getZ(),8,20);}}
}
