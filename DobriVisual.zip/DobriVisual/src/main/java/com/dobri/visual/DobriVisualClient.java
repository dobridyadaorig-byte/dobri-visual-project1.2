package com.dobri.visual;

import com.dobri.visual.config.ConfigManager;
import com.dobri.visual.module.ModuleManager;
import com.dobri.visual.ui.DobriScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class DobriVisualClient implements ClientModInitializer {
    public static final String MOD_ID = "dobrivisual";
    public static ModuleManager MODULES;
    public static ConfigManager CONFIG;
    private static KeyBinding openMenu;

    @Override public void onInitializeClient() {
        CONFIG = new ConfigManager();
        MODULES = new ModuleManager();
        CONFIG.load(MODULES);
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dobrivisual.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen instanceof DobriScreen) client.setScreen(null);
                else client.setScreen(new DobriScreen());
            }
            MODULES.tick(client);
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> MODULES.renderHud(MinecraftClient.getInstance(), drawContext));
    }

    public static void saveConfig() { if (CONFIG != null && MODULES != null) CONFIG.save(MODULES); }
    public static void notify(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) client.player.sendMessage(Text.literal("§5[DOBRI] §f" + message), true);
    }
}
