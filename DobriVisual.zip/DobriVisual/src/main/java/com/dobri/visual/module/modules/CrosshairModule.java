package com.dobri.visual.module.modules;
import com.dobri.visual.module.*;
public final class CrosshairModule extends ClientModule { public CrosshairModule(){super("Custom Crosshair","Reserved for configurable crosshair rendering; vanilla crosshair is unchanged in this build.",ModuleCategory.VISUALS);} }
