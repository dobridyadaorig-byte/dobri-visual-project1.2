package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class FpsCounter extends HudModule {
 public FpsCounter(){super("FPS Counter","Shows the current frame rate.");}
 public void render(MinecraftClient c, DrawContext d){text(c,d,"FPS  §d"+c.getCurrentFps(),8,8);}
}
