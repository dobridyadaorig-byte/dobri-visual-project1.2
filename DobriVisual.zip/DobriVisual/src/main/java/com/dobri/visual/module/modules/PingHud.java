package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class PingHud extends HudModule {
 public PingHud(){super("Ping Display","Shows latency when connected to a multiplayer server.");}
 public void render(MinecraftClient c, DrawContext d){if(c.player!=null&&c.getNetworkHandler()!=null){var e=c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());if(e!=null)text(c,d,"PING  §d"+e.getLatency()+" ms",8,44);}}
}
