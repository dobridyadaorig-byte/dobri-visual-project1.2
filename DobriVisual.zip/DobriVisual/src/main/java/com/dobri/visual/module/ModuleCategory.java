package com.dobri.visual.module;

public enum ModuleCategory {
    VISUALS("Visuals"), HUD("HUD"), PLAYER("Player"), WORLD("World"), UTILITY("Utility"), COSMETICS("Cosmetics"), SERVER("Server helpers");
    public final String title;
    ModuleCategory(String title) { this.title = title; }
}
