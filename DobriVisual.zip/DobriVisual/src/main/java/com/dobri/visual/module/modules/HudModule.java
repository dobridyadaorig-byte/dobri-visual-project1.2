package com.dobri.visual.module.modules;

import com.dobri.visual.module.ClientModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule extends ClientModule {
    protected HudModule(String name, String description) { super(name, description, com.dobri.visual.module.ModuleCategory.HUD); }
    public abstract void render(MinecraftClient client, DrawContext context);
    protected void text(MinecraftClient client, DrawContext context, String value, int x, int y) {
        context.drawTextWithShadow(client.textRenderer, value, x, y, 0xFFEAE8FF);
    }
}
