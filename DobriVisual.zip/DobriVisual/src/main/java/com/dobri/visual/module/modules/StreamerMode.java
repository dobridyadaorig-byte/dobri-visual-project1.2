package com.dobri.visual.module.modules;
import com.dobri.visual.module.*;
public final class StreamerMode extends ClientModule { public StreamerMode(){super("Streamer Mode","Privacy display filtering is planned; no text is hidden yet.",ModuleCategory.UTILITY);} }
