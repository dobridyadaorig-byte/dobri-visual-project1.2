package com.dobri.visual.module.modules;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.DrawContext;
public final class WorldInfoHud extends HudModule {
 public WorldInfoHud(){super("World Information","Shows current dimension and time.");}
 public void render(MinecraftClient c, DrawContext d){if(c.world!=null)text(c,d,"TIME  §d"+c.world.getTimeOfDay()%24000,8,116);}
}
