package com.dobri.visual.module.modules;
import com.dobri.visual.module.*;
public final class ParticleLimiter extends ClientModule { public ParticleLimiter(){super("Particle Settings","Module entry reserved; does not alter Minecraft particle settings yet.",ModuleCategory.WORLD);} }
