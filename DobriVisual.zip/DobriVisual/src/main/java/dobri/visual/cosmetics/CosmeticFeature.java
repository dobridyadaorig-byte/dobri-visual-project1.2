package dobri.visual.cosmetics;
import dobri.visual.module.Module;
import dobri.visual.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OrderedRenderCommandQueue;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
/** Рисует шляпу и крылья на ЛОКАЛЬНОМ игроке (другие игроки их не видят — мод стоит только у тебя). */
public class CosmeticFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
  public CosmeticFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> ctx) { super(ctx); }
  @Override
  public void render(MatrixStack m, OrderedRenderCommandQueue q, int light, PlayerEntityRenderState s, float limbAngle, float limbDistance) {
    var mc = MinecraftClient.getInstance();
    if (mc.player == null || s.id != mc.player.getId()) return;
    Module hat = ModuleManager.get("Hat"), wings = ModuleManager.get("Wings");
    if (hat != null && hat.isEnabled()) {
      int st = (int) Math.round(hat.n("Style")); float sc = (float) hat.n("Scale");
      m.push();
      if (s.isInSneakingPose) m.translate(0f, 4.2f / 16f, 0f);
      m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(s.relativeHeadYaw));
      m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(s.pitch));
      m.scale(sc, sc, sc);
      q.submitModelPart(CosmeticModels.hat(st), m, RenderLayer.getEntityCutoutNoCull(CosmeticModels.hatTex(st)), light, OverlayTexture.DEFAULT_UV, null);
      m.pop();
    }
    if (wings != null && wings.isEnabled()) {
      int st = (int) Math.round(wings.n("Style")); float sc = (float) wings.n("Scale");
      ModelPart root = CosmeticModels.wings(st);
      float flap = (float) (wings.n("Flap") * Math.sin(s.age * 0.35f) * 0.5f + wings.n("Flap") * 0.5f);
      float ang = (float) Math.toRadians(25 + flap);
      root.getChild("r").yaw = -ang; root.getChild("l").yaw = ang;
      m.push();
      if (s.isInSneakingPose) { m.translate(0f, 3f / 16f, 0f); m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(28f)); }
      m.scale(sc, sc, sc);
      q.submitModelPart(root, m, RenderLayer.getEntityCutoutNoCull(CosmeticModels.wingTex(st)), light, OverlayTexture.DEFAULT_UV, null);
      m.pop();
    }
  }
}
