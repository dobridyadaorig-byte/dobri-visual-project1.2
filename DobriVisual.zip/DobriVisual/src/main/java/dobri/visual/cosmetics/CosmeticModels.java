package dobri.visual.cosmetics;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModelPartNames;
import net.minecraft.client.model.ModelPart;
import net.minecraft.util.Identifier;
/** Процедурные 3D-модели шляп и крыльев (кубоиды + простые текстуры из ресурсов). */
public class CosmeticModels {
  public static final String[] HATS = {"Top Hat", "Crown", "Wizard Hat", "Cat Ears", "Halo"};
  public static final String[] WINGS = {"Angel", "Demon", "Butterfly"};
  // кубоиды: x, y, z, w, h, d (пиксели, система координат модели игрока: голова сверху = y -8)
  private static final float[][][] HAT = {
    {{-6,-9,-6,12,1,12}, {-4,-15,-4,8,6,8}},
    {{-4.5f,-11,-4.5f,9,3,9}, {-4.5f,-14,-4.5f,2,3,2}, {2.5f,-14,-4.5f,2,3,2}, {-4.5f,-14,2.5f,2,3,2}, {2.5f,-14,2.5f,2,3,2}, {-1,-14,-4.5f,2,3,1}},
    {{-7,-9,-7,14,1,14}, {-4,-13,-4,8,4,8}, {-3,-17,-3,6,4,6}, {-2,-21,-2,4,4,4}, {-1,-24,-1,2,3,2}},
    {{-4.5f,-11,-2,3,3,1}, {1.5f,-11,-2,3,3,1}, {-4,-9,-2,2,1,1}, {2,-9,-2,2,1,1}},
    {{-4,-13,-4,8,0.6f,1}, {-4,-13,3,8,0.6f,1}, {-4,-13,-3,1,0.6f,6}, {3,-13,-3,1,0.6f,6}}
  };
  // кубоиды правого крыла: x (от позвоночника наружу), y, w, h; глубина 1
  private static final float[][][] WING = {
    {{0,-4,14,3}, {0,0,13,3}, {0,4,11,3}, {0,8,8,3}, {0,12,5,3}},
    {{0,-4,12,2}, {1,-2,11,4}, {3,2,9,4}, {5,6,6,4}},
    {{0,-6,10,8}, {0,2,8,7}}
  };
  private static ModelPart[] hats = new ModelPart[HAT.length], wings = new ModelPart[WING.length];
  public static ModelPart hat(int i) {
    if (hats[i] == null) {
      ModelData md = new ModelData(); ModelPartBuilder b = ModelPartBuilder.create().uv(0, 0);
      for (float[] q : HAT[i]) b.cuboid(q[0], q[1], q[2], q[3], q[4], q[5]);
      md.getRoot().addChild("hat", b, ModelTransform.NONE);
      hats[i] = TexturedModelData.of(md, 64, 64).createModel().getChild("hat");
    }
    return hats[i];
  }
  /** Корень с детьми "l" и "r". */
  public static ModelPart wings(int i) {
    if (wings[i] == null) {
      ModelData md = new ModelData();
      for (int side = 0; side < 2; side++) {
        float sg = side == 0 ? 1 : -1; ModelPartBuilder b = ModelPartBuilder.create().uv(0, 0);
        for (float[] q : WING[i]) { float x = sg > 0 ? q[0] : -(q[0] + q[2]); b.cuboid(x, q[1], 0, q[2], q[3], 1); }
        md.getRoot().addChild(side == 0 ? "r" : "l", b, ModelTransform.pivot(sg * 2, 2, 2.5f));
      }
      wings[i] = TexturedModelData.of(md, 64, 64).createModel();
    }
    return wings[i];
  }
  public static Identifier hatTex(int i) { return Identifier.of("dobri_visual", "textures/cosmetics/hat_" + i + ".png"); }
  public static Identifier wingTex(int i) { return Identifier.of("dobri_visual", "textures/cosmetics/wings_" + i + ".png"); }
}
