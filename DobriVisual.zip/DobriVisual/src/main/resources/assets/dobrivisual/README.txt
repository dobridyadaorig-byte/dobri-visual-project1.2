DOBRI VISUAL assets
- icon.png: original project icon
- lang/en_us.json and lang/ru_ru.json: keybinding translations
