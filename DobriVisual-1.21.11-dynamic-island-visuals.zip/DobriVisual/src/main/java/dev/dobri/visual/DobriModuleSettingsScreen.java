package dev.dobri.visual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Lightweight per-module settings page. */
public final class DobriModuleSettingsScreen extends Screen {
    private final Screen parent;
    private final String module;
    private int colorIndex = 0;
    private int transparency = 80;
    private boolean glow = true;
    private static final String[] COLORS = {"#B56CFF", "#45C8FF", "#54E39A", "#FF526A"};
    public DobriModuleSettingsScreen(Screen parent, String module) {
        super(Text.literal(module + " settings")); this.parent = parent; this.module = module;
    }
    @Override protected void init() {
        int cx = width / 2 - 100, y = height / 2 - 30;
        addDrawableChild(ButtonWidget.builder(Text.literal("Цвет: " + COLORS[colorIndex]), b -> {
            colorIndex = (colorIndex + 1) % COLORS.length; b.setMessage(Text.literal("Цвет: " + COLORS[colorIndex]));
        }).dimensions(cx, y, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Прозрачность предметов: " + transparency + "%"), b -> {
            transparency = (transparency + 20) % 101; b.setMessage(Text.literal("Прозрачность предметов: " + transparency + "%"));
        }).dimensions(cx, y + 26, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Свечение: " + (glow ? "ВКЛ" : "ВЫКЛ")), b -> {
            glow = !glow; b.setMessage(Text.literal("Свечение: " + (glow ? "ВКЛ" : "ВЫКЛ")));
        }).dimensions(cx, y + 52, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> client.setScreen(parent)).dimensions(cx, y + 84, 200, 20).build());
    }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.drawTextWithShadow(textRenderer, Text.literal(module + " — настройки").formatted(Formatting.LIGHT_PURPLE), width / 2 - 100, height / 2 - 62, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Параметры интерфейса; не все модули реализованы функционально."), width / 2 - 145, height / 2 + 112, 0xFFB9A7D7);
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
}
