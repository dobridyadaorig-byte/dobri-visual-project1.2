package dev.dobri.visual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.ArrayList;
import java.util.List;

/** Visual UI prototype. Module switches currently store UI state only. */
public final class DobriVisualScreen extends Screen {
    private static final int BG = 0xE90A0D18, PANEL = 0xF0181C2D, PANEL2 = 0xF021263A;
    private static final int ACCENT = 0xFFB56CFF, FG = 0xFFF4F2FF, MUTED = 0xFF9DA6C2;
    private final List<Entry> entries = new ArrayList<>();
    private String category = "HUD";
    private int scroll;
    private TextFieldWidget protectedNickField;

    public DobriVisualScreen() {
        super(Text.literal("Dobri Visual"));
        add("Visual", "Lite Visuals", "Дальность до 8 чанков и отключение теней; не загружает шейдерпаки");
        add("HUD", "Coordinates", "Координаты игрока");
        add("HUD", "FPS Counter", "Счётчик FPS");
        add("HUD", "Keystrokes", "Нажатые клавиши WASD и прыжок");
        add("HUD", "Saturation", "Уровень голода");
        add("HUD", "Armor HUD", "Прочность надетой брони");
        add("HUD", "Target HUD", "Здоровье сущности под прицелом");
        add("HUD", "Dynamic Island", "Индикатор цели сверху");
    }
    private void add(String group, String name, String desc) { entries.add(new Entry(group, name, desc)); }

    @Override protected void init() {
        int x = Math.max(8, (width - 760) / 2), y = 54;
        String[] tabs = {"Visual", "HUD"};
        int tabWidth = 100;
        for (int i = 0; i < tabs.length; i++) {
            String tab = tabs[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(tab.equals(category) ? "§d" + tab : tab), b -> { category = tab; scroll = 0; clearAndInit(); })
                    .dimensions(x + 6 + i * tabWidth, 20, tabWidth - 3, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close()).dimensions(width - 86, height - 28, 78, 20).build());
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Minimal transparent-style module list: no full-screen or row panels.
        int x = Math.max(8, (width - 760) / 2), y = 18;
        ctx.drawTextWithShadow(textRenderer, Text.literal("DOBRI").formatted(Formatting.BOLD, Formatting.LIGHT_PURPLE), x + 8, y, ACCENT);
        ctx.drawTextWithShadow(textRenderer, Text.literal("ЛКМ — переключить   •   ПКМ — настройки"), x + 100, y, FG);
        ctx.drawTextWithShadow(textRenderer, Text.literal(category.toUpperCase()), x + 8, y + 30, ACCENT);
        int row = y + 54;
        for (Entry e : entries) {
            if (!e.group.equals(category)) continue;
            int ry = row - scroll; row += 28;
            if (ry < y + 48 || ry > height - 30) continue;
            int color = e.enabled ? 0xFF72E6B1 : FG;
            ctx.drawTextWithShadow(textRenderer, Text.literal(e.enabled ? "●" : "○"), x + 10, ry, color);
            ctx.drawTextWithShadow(textRenderer, Text.literal(e.name), x + 28, ry, color);
            ctx.drawTextWithShadow(textRenderer, Text.literal("›"), x + 220, ry, MUTED);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 1) {
            int x = Math.max(8, (width - 760) / 2), y = 18, row = y + 54;
            for (Entry e : entries) {
                if (!e.group.equals(category)) continue;
                int ry = row - scroll; row += 28;
                if (ry < y + 48 || ry > height - 30) continue;
                if (mouseY >= ry - 4 && mouseY <= ry + 16 && mouseX >= x + 8 && mouseX <= x + 760) {
                    if (client != null) client.setScreen(new DobriModuleSettingsScreen(this, e.name));
                    return true;
                }
            }
        } else if (button == 0) {
            int x = Math.max(8, (width - 760) / 2), y = 18, row = y + 54;
            for (Entry e : entries) {
                if (!e.group.equals(category)) continue;
                int ry = row - scroll; row += 28;
                if (ry < y + 48 || ry > height - 30) continue;
                if (mouseY >= ry - 4 && mouseY <= ry + 16 && mouseX >= x + 8 && mouseX <= x + 760) {
                    boolean next = !DobriModules.enabled(e.name);
                    e.enabled = next;
                    DobriModules.set(e.name, next);
                    if (e.name.equals("Lite Visuals")) DobriModules.applyLiteShaders(net.minecraft.client.MinecraftClient.getInstance(), next);
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(scroll + (verticalAmount > 0 ? -54 : 54), 540)); clearAndInit(); return true;
    }
    @Override public boolean shouldPause() { return false; }
    private static final class Entry {
        final String group, name, desc; boolean enabled;
        Entry(String group, String name, String desc) { this.group = group; this.name = name; this.desc = desc; }
    }
}
