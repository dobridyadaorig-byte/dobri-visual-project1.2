package dev.dobri.visual.mixin;

import dev.dobri.visual.DobriModules;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Client-side presentation tweak: rotate dropped item models into a flat pose. */
@Mixin(ItemEntityRenderer.class)
public abstract class ItemPhysicsMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void dobriVisual$layDroppedItemsFlat(ItemEntity entity, float yaw, float tickDelta,
            MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (DobriModules.enabled("Item Physics")) {
            // A local X rotation makes the dropped-item model lie horizontally rather than stand upright.
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
        }
    }
}
