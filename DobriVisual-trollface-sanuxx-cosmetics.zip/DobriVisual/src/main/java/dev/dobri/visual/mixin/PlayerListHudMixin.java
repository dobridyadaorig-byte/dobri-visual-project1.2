package dev.dobri.visual.mixin;

import dev.dobri.visual.DobriModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Local-only nickname presentation. This does not change the account or server identity. */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void dobriVisual$replaceListedNickname(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        if (!DobriModules.enabled("Protect Mode") || entry == null || entry.getProfile() == null) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        String realName = entry.getProfile().getName();
        String ownName = client.player.getGameProfile().getName();
        if (realName == null || ownName == null || !realName.equals(ownName)) return;
        cir.setReturnValue(Text.literal(DobriModules.protectedNickname()));
    }
}
