# Dobri Visual

Fabric client-side visual enhancement mod for Minecraft 1.21.11.

## Updated in this edition
- Liquid Glass is the default UI theme, with translucent layered panels, highlights, and more rounded controls.
- Branding is consistently **Dobri Visual**.
- World Fog now spawns ambient mist particles in world coordinates around the player; it no longer paints a gradient over the screen. Density, radius, height, hue, rainbow, and soft-cloud options are available.
- Wing cosmetics have fuller layered silhouettes for Angel, Demon, and Butterfly styles, plus scale, spread, flap, and idle-motion settings.
- Existing HUD editor, keybinds, cosmetics, crosshair, particle effects, freelook, and visual modules are retained.

## Build
Use Java 21 and run `./gradlew build` (or `gradlew.bat build` on Windows).

## Шрифт Dobri Visual
Проект включает шрифт Cabin — более мягкий, современный и округлый шрифт с поддержкой кириллицы. Он подключён через ресурс `assets/minecraft/font/default.json`, поэтому заменяет стандартный шрифт Minecraft во всём интерфейсе игры. Если шрифт не применился после установки, проверьте, что ресурсы мода включены и перезапустите игру.
