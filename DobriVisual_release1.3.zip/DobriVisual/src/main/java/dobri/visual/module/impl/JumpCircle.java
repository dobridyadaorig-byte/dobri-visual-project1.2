package dobri.visual.module.impl;
import java.util.*;
import net.minecraft.particle.DustParticleEffect;
public class JumpCircle extends dobri.visual.module.Module {
  private final List<double[]> rings = new ArrayList<>(); private boolean was = true;
  public JumpCircle() {
    super("Jump Circle", "Cosmetics", "Расширяющееся кольцо под ногами при прыжке (локальные частицы)", false, 0, 0);
    num("Size", 2.5, 0.5, 6); num("Life", 20, 6, 60); num("Thickness", 0.6, 0.3, 1.5); num("Hue", 200, 0, 360); bool("Rainbow", false);
  }
  @Override public void onTick() {
    var p = mc.player; var w = mc.world; if (p == null || w == null) return;
    boolean g = p.isOnGround();
    if (isEnabled() && was && !g && p.getVelocity().y > 0.1 && rings.size() < 4) rings.add(new double[]{p.getX(), p.getY() + 0.05, p.getZ(), 0});
    was = g;
    Iterator<double[]> it = rings.iterator();
    while (it.hasNext()) {
      double[] r = it.next(); r[3]++;
      if (r[3] > n("Life")) { it.remove(); continue; }
      double rad = n("Size") * r[3] / n("Life"); int pts = Math.max(12, (int) (rad * 14));
      var fx = new DustParticleEffect(Fx.rgb(this), (float) n("Thickness"));
      for (int i = 0; i < pts; i++) { double a = 2 * Math.PI * i / pts; w.addParticleClient(fx, r[0] + Math.cos(a) * rad, r[1], r[2] + Math.sin(a) * rad, 0, 0, 0); }
    }
  }
}
