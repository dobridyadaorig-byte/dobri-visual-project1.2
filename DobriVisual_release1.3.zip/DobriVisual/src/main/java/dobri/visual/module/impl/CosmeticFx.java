package dobri.visual.module.impl;
import net.minecraft.particle.*;
public class CosmeticFx extends dobri.visual.module.Module {
  public enum Mode { PARTICLES, AURA, TRAIL, ORBITS }
  private final Mode mode; private double ang; private final java.util.Random rnd = new java.util.Random();
  public CosmeticFx(String name, Mode mode, String desc) {
    super(name, "Cosmetics", desc + " (виден только тебе)", false, 0, 0); this.mode = mode;
    num("Density", 2, 1, 10); num("Radius", 0.8, 0.3, 2.5); num("Speed", 0.2, 0.05, 0.6); num("Hue", 280, 0, 360); bool("Rainbow", false); bool("First Person", true);
    if (mode == Mode.PARTICLES) num("Style", 0, 0, 4);
  }
  @Override public void onTick() {
    var p = mc.player; var w = mc.world; if (!isEnabled() || p == null || w == null) return;
    if (!b("First Person") && mc.options.getPerspective().isFirstPerson()) return;
    int d = (int) n("Density"); double r = n("Radius"); ang += n("Speed");
    var dust = new DustParticleEffect(Fx.rgb(this), 0.7f);
    switch (mode) {
      case PARTICLES -> {
        ParticleEffect e = switch ((int) n("Style")) { case 1 -> ParticleTypes.HEART; case 2 -> ParticleTypes.SNOWFLAKE; case 3 -> ParticleTypes.ELECTRIC_SPARK; case 4 -> dust; default -> ParticleTypes.END_ROD; };
        for (int i = 0; i < d; i++) { double a = rnd.nextDouble() * 6.283, rr = r * (0.5 + rnd.nextDouble() * 0.5);
          w.addParticleClient(e, p.getX() + Math.cos(a) * rr, p.getY() + rnd.nextDouble() * 1.8, p.getZ() + Math.sin(a) * rr, 0, 0.01, 0); }
      }
      case AURA -> { for (int i = 0; i < d; i++) { double a = rnd.nextDouble() * 6.283, y = rnd.nextDouble() * 1.9, rr = r * Math.sin(Math.PI * y / 1.9) + 0.2;
          w.addParticleClient(dust, p.getX() + Math.cos(a) * rr, p.getY() + y, p.getZ() + Math.sin(a) * rr, 0, 0, 0); } }
      case TRAIL -> { var v = p.getVelocity(); if (v.x * v.x + v.z * v.z > 0.0025) for (int i = 0; i < d; i++)
          w.addParticleClient(dust, p.getX() + (rnd.nextDouble() - 0.5) * 0.4, p.getY() + 0.1, p.getZ() + (rnd.nextDouble() - 0.5) * 0.4, 0, 0, 0); }
      case ORBITS -> { for (int k = 0; k < 3; k++) { double a = ang + k * 2.094;
          w.addParticleClient(dust, p.getX() + Math.cos(a) * r, p.getY() + 1.0 + 0.3 * Math.sin(ang + k), p.getZ() + Math.sin(a) * r, 0, 0, 0); } }
    }
  }
}
