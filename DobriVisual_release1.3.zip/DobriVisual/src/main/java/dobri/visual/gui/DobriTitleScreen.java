package dobri.visual.gui;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.text.Text;
public class DobriTitleScreen extends Screen {
  private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Settings", "Cosmetics", "Quit Game"};
  public DobriTitleScreen() { super(Text.literal("Dobri Visual")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  private int bx(int i) { return width / 2 - 150 + i * 60 + 10; } private int by() { return height / 2 + 20; }
  @Override public void render(DrawContext c, int mx, int my, float d) {
    long t = System.currentTimeMillis();
    int top = blend(0xFF0B0B12, 0xFF1A1030, (Math.sin(t / 3000.0) + 1) / 2);
    c.fillGradient(0, 0, width, height, top, 0xFF050508);
    for (int i = 0; i < 24; i++) {
      int px = (int) ((i * 97 + t / 40.0) % width), py = (int) (height - ((i * 61 + t / 25.0) % height));
      c.fill(px, py, px + 2, py + 2, 0x558B5CF6);
    }
    String clock = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    c.getMatrices().pushMatrix(); c.getMatrices().translate(width / 2f, height / 2f - 50); c.getMatrices().scale(5f, 5f);
    c.drawCenteredTextWithShadow(textRenderer, clock, 0, 0, 0xFFFFFFFF);
    c.getMatrices().popMatrix();
    for (int i = 0; i < 5; i++) {
      int x = bx(i), y = by(); boolean h = mx >= x && mx <= x + 40 && my >= y && my <= y + 40; int o = h ? 2 : 0;
      Draw.round(c, x, y - o, 40, 40, 20, h ? 0x66FFFFFF : 0x40FFFFFF);
      c.drawCenteredTextWithShadow(textRenderer, String.valueOf(LABELS[i].charAt(0)), x + 20, y + 16 - o, 0xFFFFFFFF);
      c.drawCenteredTextWithShadow(textRenderer, LABELS[i], x + 20, y + 48, 0xFFCCCCCC);
    }
    c.drawText(textRenderer, "Minecraft 1.21.11 | Dobri Visual 1.0.0", 4, height - 12, 0xFF888888, false);
  }
  private static int blend(int a, int b, double f) {
    int r = 0; for (int s = 0; s <= 16; s += 8) r |= ((int) (((a >> s) & 255) * (1 - f) + ((b >> s) & 255) * f)) << s;
    return r | 0xFF000000;
  }
  @Override public boolean mouseClicked(Click click, boolean doubled) {
    for (int i = 0; i < 5; i++) {
      int x = bx(i), y = by();
      if (click.x() >= x && click.x() <= x + 40 && click.y() >= y && click.y() <= y + 40) {
        switch (i) {
          case 0 -> client.setScreen(new SelectWorldScreen(this));
          case 1 -> client.setScreen(new MultiplayerScreen(this));
          case 2 -> client.setScreen(new OptionsScreen(this, client.options));
          case 3 -> client.setScreen(new MenuScreen(5));
          default -> client.scheduleStop();
        }
        return true;
      }
    }
    return false;
  }
}
