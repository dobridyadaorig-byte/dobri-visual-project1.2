package dobri.visual.gui;
import net.minecraft.client.gui.DrawContext;
public class Draw {
  public static int fade(int col, float a) { int al = (int) (((col >>> 24) & 255) * Math.max(0f, Math.min(1f, a))); return (al << 24) | (col & 0xFFFFFF); }
  public static void round(DrawContext c, int x, int y, int w, int h, int r, int col) {
    r = Math.min(r, Math.min(w, h) / 2);
    c.fill(x + r, y, x + w - r, y + h, col);
    c.fill(x, y + r, x + r, y + h - r, col); c.fill(x + w - r, y + r, x + w, y + h - r, col);
    for (int i = 0; i < r; i++) {
      double dy = r - i - 0.5;
      int inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
      c.fill(x + inset, y + i, x + r, y + i + 1, col); c.fill(x + w - r, y + i, x + w - inset, y + i + 1, col);
      c.fill(x + inset, y + h - i - 1, x + r, y + h - i, col); c.fill(x + w - r, y + h - i - 1, x + w - inset, y + h - i, col);
    }
  }
  /** Панель; в Liquid Glass добавляются блик, слоистость и тонкая светлая граница. */
  public static void panel(DrawContext c, int x, int y, int w, int h, int r, int col, boolean glass) {
    round(c, x, y, w, h, r, col);
    if (!glass) return;
    round(c, x + 2, y + 2, w - 4, h / 2 - 2, Math.max(2, r - 2), 0x16FFFFFF);
    int b = 0x40FFFFFF;
    c.fill(x + r, y, x + w - r, y + 1, b); c.fill(x + r, y + h - 1, x + w - r, y + h, 0x20FFFFFF);
    c.fill(x, y + r, x + 1, y + h - r, b); c.fill(x + w - 1, y + r, x + w, y + h - r, 0x20FFFFFF);
  }
  public static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
}
