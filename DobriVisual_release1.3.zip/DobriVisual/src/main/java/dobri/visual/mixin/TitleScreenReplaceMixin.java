package dobri.visual.mixin;
import dobri.visual.gui.DobriTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(MinecraftClient.class)
public class TitleScreenReplaceMixin {
  @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
  private Screen dobri$replace(Screen s) { return s != null && s.getClass() == TitleScreen.class ? new DobriTitleScreen() : s; }
}
