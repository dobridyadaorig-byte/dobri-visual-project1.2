package dev.dobri.visual.mixin;

import dev.dobri.visual.DobriModules;
import dev.dobri.visual.LogoutConfirmationScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Screen.class)
public abstract class LogoutProtectionMixin {
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void dobri$confirmDisconnect(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        Screen screen = (Screen) (Object) this;
        if (!DobriModules.enabled("Logout Protection") || !(screen instanceof GameMenuScreen) || button != 0) return;
        for (var child : screen.children()) {
            if (!(child instanceof ButtonWidget widget)) continue;
            String label = widget.getMessage().getString().toLowerCase(java.util.Locale.ROOT);
            if (!(label.contains("disconnect") || label.contains("leave server") || label.contains("disconnect and save"))) continue;
            if (mouseX >= widget.getX() && mouseX < widget.getX() + widget.getWidth()
                    && mouseY >= widget.getY() && mouseY < widget.getY() + widget.getHeight()) {
                MinecraftClient.getInstance().setScreen(new LogoutConfirmationScreen(screen));
                cir.setReturnValue(true);
                return;
            }
        }
    }
}
