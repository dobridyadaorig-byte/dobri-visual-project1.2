```java
package dev.dobri.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class DobriVisualClient implements ClientModInitializer {

    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFAAAAAA;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.dobrivisual.open_menu",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_RIGHT_SHIFT,
                        KeyBinding.Category.MISC
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new DobriVisualScreen());
                }
            }
        });

        HudElementRegistry.addLast(
                Identifier.of("dobrivisual", "hud"),
                (drawContext, tickCounter) -> renderHud(
                        MinecraftClient.getInstance(),
                        drawContext
                )
        );
    }

    private static void renderHud(MinecraftClient client, DrawContext ctx) {
        if (client.player == null || client.world == null) {
            return;
        }

        int x = 8;
        int y = 8;

        if (DobriModules.enabled("Coordinates")) {
            String coordinates = String.format(
                    "XYZ  %.1f  %.1f  %.1f",
                    client.player.getX(),
                    client.player.getY(),
                    client.player.getZ()
            );

            y = panelText(client, ctx, coordinates, x, y, WHITE);
        }

        if (DobriModules.enabled("FPS")) {
            String fps = "FPS  " + client.getCurrentFps();
            y = panelText(client, ctx, fps, x, y, GREEN);
        }

        if (DobriModules.enabled("Armor HUD")) {
            StringBuilder armor = new StringBuilder("ARMOR  ");

            EquipmentSlot[] slots = {
                    EquipmentSlot.HEAD,
                    EquipmentSlot.CHEST,
                    EquipmentSlot.LEGS,
                    EquipmentSlot.FEET
            };

            for (EquipmentSlot slot : slots) {
                ItemStack stack = client.player.getEquippedStack(slot);

                if (stack.isEmpty()) {
                    armor.append("--  ");
                } else if (stack.isDamageable()) {
                    int durability = Math.max(
                            0,
                            stack.getMaxDamage() - stack.getDamage()
                    );

                    armor.append(durability).append("  ");
                } else {
                    armor.append("OK  ");
                }
            }

            y = panelText(client, ctx, armor.toString(), x, y, MUTED);
        }

        if (DobriModules.enabled("Target HUD")) {
            Entity target = getTarget(client);

            if (target instanceof LivingEntity livingTarget) {
                String name = livingTarget.getName().getString();
                String health = String.format(
                        "%.1f HP",
                        livingTarget.getHealth()
                );

                y = panelText(
                        client,
                        ctx,
                        "TARGET  " + name,
                        x,
                        y,
                        WHITE
                );

                int healthColor = livingTarget.getHealth() > 8.0F
                        ? GREEN
                        : RED;

                y = panelText(
                        client,
                        ctx,
                        "HEALTH  " + health,
                        x,
                        y,
                        healthColor
                );
            } else {
                y = panelText(
                        client,
                        ctx,
                        "TARGET  None",
                        x,
                        y,
                        MUTED
                );
            }
        }
    }

    private static Entity getTarget(MinecraftClient client) {
        if (client.crosshairTarget instanceof EntityHitResult entityHit) {
            return entityHit.getEntity();
        }

        if (client.crosshairTarget != null
                && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            return ((EntityHitResult) client.crosshairTarget).getEntity();
        }

        return null;
    }

    private static int panelText(
            MinecraftClient client,
            DrawContext ctx,
            String text,
            int x,
            int y,
            int color
    ) {
        ctx.drawText(
                client.textRenderer,
                text,
                x,
                y,
                color,
                true
        );

        return y + 12;
    }
}
```