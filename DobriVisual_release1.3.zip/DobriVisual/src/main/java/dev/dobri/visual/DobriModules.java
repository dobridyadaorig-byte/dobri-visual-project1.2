package dev.dobri.visual;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Shared client-side module states. */
public final class DobriModules {
    private DobriModules() {}
    private static volatile String protectedNickname = "Player";
    private static Integer previousViewDistance;
    private static Boolean previousEntityShadows;
    public static String protectedNickname() { return protectedNickname; }
    public static void setProtectedNickname(String value) {
        if (value == null) return;
        String clean = value.replaceAll("[^A-Za-z0-9_ ]", "").trim();
        if (!clean.isEmpty()) protectedNickname = clean.substring(0, Math.min(16, clean.length()));
    }
    private static final Map<String, Boolean> STATES = new ConcurrentHashMap<>();
    static {
        STATES.put("Lite Shaders", false);
        STATES.put("Logout Protection", true);
        STATES.put("FPS Counter", true);
        STATES.put("Coordinates", true);
        STATES.put("Target HUD", true);
        STATES.put("Dynamic Island", true);
        STATES.put("Keystrokes", false);
        STATES.put("Saturation", false);
        STATES.put("Armor HUD", false);
        STATES.put("Item Physics", false);
        STATES.put("Wings", false);
        STATES.put("Capes", false);
        STATES.put("Backpacks", false);
        STATES.put("Hats", false);
        STATES.put("Pets", false);
    }
    /** Applies a conservative, reversible performance-friendly visual preset. This is not a shader-pack loader. */
    public static synchronized void applyLiteShaders(net.minecraft.client.MinecraftClient client, boolean enabled) {
        if (client == null) return;
        if (enabled) {
            if (previousViewDistance == null) previousViewDistance = client.options.getViewDistance().getValue();
            if (previousEntityShadows == null) previousEntityShadows = client.options.getEntityShadows().getValue();
            client.options.getViewDistance().setValue(Math.min(client.options.getViewDistance().getValue(), 8));
            client.options.getEntityShadows().setValue(false);
        } else {
            if (previousViewDistance != null) client.options.getViewDistance().setValue(previousViewDistance);
            if (previousEntityShadows != null) client.options.getEntityShadows().setValue(previousEntityShadows);
            previousViewDistance = null;
            previousEntityShadows = null;
        }
    }
    public static boolean enabled(String name) { return STATES.getOrDefault(name, false); }
    public static void set(String name, boolean enabled) { STATES.put(name, enabled); }
    public static boolean toggle(String name) { boolean next = !enabled(name); set(name, next); return next; }
}
